import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth, AuthProvider } from "./contexts/AuthContext";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import Ministry from "@/pages/ministry";
import Tasks from "@/pages/tasks";
import Liturgy from "@/pages/liturgy";
import Cultos from "@/pages/cultos";
import CriarCulto from "@/pages/criar-culto";
import EditarCulto from "@/pages/editar-culto";
import Escalas from "@/pages/escalas";
import Tarefas from "@/pages/tarefas";
import Cardapio from "@/pages/cardapio";
import Settings from "@/pages/settings";
import Chat from "@/pages/chat";
import RegisterUser from "@/pages/register-user";

// Protected route component
const ProtectedRoute = ({ component: Component, ...rest }: any) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div className="flex h-screen w-full items-center justify-center">Carregando...</div>;
  }

  if (!isAuthenticated) {
    window.location.href = "/auth";
    return null;
  }

  return <Component {...rest} />;
};

function Router() {
  const { isAuthenticated } = useAuth();

  return (
    <Switch>
      <Route path="/login">
        {isAuthenticated ? () => {
          // Redirect to dashboard if already authenticated
          window.location.href = "/cultos";
          return null;
        } : Login}
      </Route>
      <Route path="/auth">
        {isAuthenticated ? () => {
          // Redirect to dashboard if already authenticated
          window.location.href = "/cultos";
          return null;
        } : AuthPage}
      </Route>
      <Route path="/">
        {() => <ProtectedRoute component={Cultos} />}
      </Route>
      <Route path="/ministry/:slug">
        {(params) => <ProtectedRoute component={Ministry} slug={params.slug} />}
      </Route>
      <Route path="/tasks">
        {() => <ProtectedRoute component={Tasks} />}
      </Route>
      <Route path="/liturgy">
        {() => <ProtectedRoute component={Liturgy} />}
      </Route>
      <Route path="/cultos">
        {() => <ProtectedRoute component={Cultos} />}
      </Route>
      <Route path="/criar-culto">
        {() => <ProtectedRoute component={CriarCulto} />}
      </Route>
      <Route path="/editar-culto/:id">
        {(params) => <ProtectedRoute component={EditarCulto} id={params.id} />}
      </Route>
      <Route path="/escalas">
        {() => <ProtectedRoute component={Escalas} />}
      </Route>
      <Route path="/tarefas">
        {() => <ProtectedRoute component={Tarefas} />}
      </Route>
      <Route path="/cardapio">
        {() => <ProtectedRoute component={Cardapio} />}
      </Route>
      <Route path="/settings">
        {() => <ProtectedRoute component={Settings} />}
      </Route>
      <Route path="/chat">
        {() => <ProtectedRoute component={Chat} />}
      </Route>
      <Route path="/notifications">
        {() => <ProtectedRoute component={Settings} />}
      </Route>
      <Route path="/register-user">
        {() => <ProtectedRoute component={RegisterUser} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
