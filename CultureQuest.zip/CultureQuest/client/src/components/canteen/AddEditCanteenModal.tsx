import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Service, InsertCanteenMenu } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDate } from "@/lib/utils";
import { CanteenMenuWithDetails } from "@/lib/types";
import { Plus, X } from "lucide-react";

// Create schema for form validation
const canteenMenuSchema = z.object({
  serviceId: z.string().min(1, "Serviço é obrigatório"),
  items: z.array(z.string().min(1)),
  status: z.enum(["pending", "completed", "cancelled"]),
});

type CanteenMenuFormValues = z.infer<typeof canteenMenuSchema>;

interface AddEditCanteenModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  menu?: CanteenMenuWithDetails | null;
  services: Service[];
}

export default function AddEditCanteenModal({
  open,
  onClose,
  onSave,
  menu,
  services
}: AddEditCanteenModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [menuItems, setMenuItems] = useState<string[]>([]);
  const [newItem, setNewItem] = useState("");

  // Initialize form with default values or menu values
  const form = useForm<CanteenMenuFormValues>({
    resolver: zodResolver(canteenMenuSchema),
    defaultValues: {
      serviceId: menu?.serviceId.toString() || "",
      items: menu?.items || [],
      status: menu?.status || "pending",
    },
  });

  // Update menu items when menu changes
  useEffect(() => {
    if (menu?.items) {
      setMenuItems(menu.items);
      form.setValue("items", menu.items);
    } else {
      setMenuItems([]);
      form.setValue("items", []);
    }
  }, [menu, form]);

  // Create or update menu mutation
  const mutation = useMutation({
    mutationFn: async (data: InsertCanteenMenu) => {
      if (menu) {
        // Update existing menu
        return apiRequest("PUT", `/api/canteenmenus/${menu.id}`, data);
      } else {
        // Create new menu
        return apiRequest("POST", `/api/canteenmenus`, data);
      }
    },
    onSuccess: () => {
      toast({
        title: menu ? "Cardápio atualizado" : "Cardápio criado",
        description: menu ? "O cardápio foi atualizado com sucesso" : "Novo cardápio criado com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/canteenmenus'] });
      onSave();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Falha ao ${menu ? "atualizar" : "criar"} cardápio: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CanteenMenuFormValues) => {
    if (!user) return;

    const menuData: InsertCanteenMenu = {
      serviceId: parseInt(data.serviceId),
      items: menuItems,
      responsibleId: user.id,
      status: data.status,
    };

    mutation.mutate(menuData);
  };

  const handleAddItem = () => {
    if (newItem.trim()) {
      const updatedItems = [...menuItems, newItem.trim()];
      setMenuItems(updatedItems);
      form.setValue("items", updatedItems);
      setNewItem("");
    }
  };

  const handleRemoveItem = (index: number) => {
    const updatedItems = menuItems.filter((_, i) => i !== index);
    setMenuItems(updatedItems);
    form.setValue("items", updatedItems);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{menu ? "Editar Cardápio" : "Novo Cardápio"}</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="serviceId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Serviço</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um serviço" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service.id} value={service.id.toString()}>
                          {formatDate(service.date)} - {service.name} - {service.time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormItem>
              <FormLabel>Itens do Cardápio</FormLabel>
              <div className="flex space-x-2">
                <Input
                  placeholder="Digite um item do cardápio"
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleAddItem}
                  disabled={!newItem.trim()}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              {form.formState.errors.items && (
                <p className="text-sm font-medium text-destructive">
                  {form.formState.errors.items.message}
                </p>
              )}

              <div className="space-y-2 mt-2">
                {menuItems.length === 0 && (
                  <p className="text-sm text-muted-foreground">Nenhum item adicionado</p>
                )}
                
                {menuItems.map((item, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-neutral-light rounded">
                    <span>{item}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveItem(index)}
                      className="h-6 w-6 p-0"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </FormItem>

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="pending">Pendente</SelectItem>
                      <SelectItem value="completed">Realizado</SelectItem>
                      <SelectItem value="cancelled">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending || menuItems.length === 0}
              >
                {mutation.isPending 
                  ? (menu ? "Atualizando..." : "Criando...")
                  : (menu ? "Atualizar" : "Criar")
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
