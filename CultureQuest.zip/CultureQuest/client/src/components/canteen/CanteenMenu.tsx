import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, Edit, Trash2, Check } from "lucide-react";
import { formatDate } from "@/lib/utils";
import { statusLabels, statusColorMap, CanteenMenuWithDetails } from "@/lib/types";
import AddEditCanteenModal from "./AddEditCanteenModal";
import { Service } from "@shared/schema";

interface CanteenMenuProps {
  ministryId: number;
}

export default function CanteenMenu({ ministryId }: CanteenMenuProps) {
  const { user } = useAuth();
  const isLeader = user?.role === "leader" && user?.ministryId === ministryId;
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentMenu, setCurrentMenu] = useState<CanteenMenuWithDetails | null>(null);

  // Fetch canteen menus
  const { data: canteenMenus, isLoading, refetch } = useQuery<CanteenMenuWithDetails[]>({
    queryKey: ['/api/canteenmenus'],
  });

  // Fetch upcoming services for creating new menus
  const { data: upcomingServices } = useQuery<Service[]>({
    queryKey: ['/api/services/upcoming'],
  });

  const handleNewMenu = () => {
    setCurrentMenu(null);
    setIsModalOpen(true);
  };

  const handleEditMenu = (menu: CanteenMenuWithDetails) => {
    setCurrentMenu(menu);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentMenu(null);
  };

  const onMenuSaved = () => {
    refetch();
    closeModal();
  };

  if (isLoading) {
    return (
      <section id="canteen-section" className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <div className="w-2 h-8 bg-status-overdue rounded-full mr-3"></div>
            <h2 className="text-xl font-bold font-montserrat">Cardápio da Cantina</h2>
          </div>
        </div>
        <div className="flex justify-center items-center h-32">
          <p>Carregando cardápios...</p>
        </div>
      </section>
    );
  }

  return (
    <section id="canteen-section" className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="w-2 h-8 bg-status-overdue rounded-full mr-3"></div>
          <h2 className="text-xl font-bold font-montserrat">Cardápio da Cantina</h2>
        </div>
        {isLeader && (
          <Button
            size="sm"
            onClick={handleNewMenu}
            className="flex items-center text-sm bg-status-overdue text-white px-3 py-1 rounded-md hover:bg-status-overdue/80"
          >
            <PlusCircle className="h-4 w-4 mr-1" />
            Novo Cardápio
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="px-4 py-3 border-b">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
              <h3 className="font-semibold">Cardápios Cadastrados</h3>
              <div className="flex items-center mt-2 sm:mt-0">
                <span className="text-sm mr-2">Filtrar por:</span>
                <select className="text-sm border rounded-md px-2 py-1">
                  <option>Todos os cultos</option>
                  <option>Domingo</option>
                  <option>Quarta-feira</option>
                  <option>Especial</option>
                </select>
              </div>
            </div>
          </div>

          {canteenMenus?.length ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
              {canteenMenus.map((menu) => (
                <Card key={menu.id} className="border rounded-lg">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">
                          Cardápio - {menu.service ? formatDate(menu.service.date, "dd/MM") : "Data não definida"}
                        </h4>
                        <p className="text-sm text-neutral-dark">
                          {menu.service 
                            ? `${menu.service.name} - ${menu.service.time}` 
                            : "Serviço não definido"}
                        </p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs ${statusColorMap[menu.status]}`}>
                        {statusLabels[menu.status]}
                      </span>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t">
                      <h5 className="text-sm font-medium">Itens do cardápio:</h5>
                      <ul className="mt-1 text-sm space-y-1">
                        {menu.items.map((item, index) => (
                          <li key={index} className="flex items-center">
                            <Check className="h-4 w-4 mr-1 text-status-completed" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t flex justify-between">
                      <span className="text-sm">Responsável: {menu.responsibleName || "Não definido"}</span>
                      {isLeader && (
                        <div className="flex space-x-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-primary hover:text-primary-dark"
                            onClick={() => handleEditMenu(menu)}
                          >
                            <Edit className="h-5 w-5" />
                          </Button>
                          {menu.status !== "completed" && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-status-overdue hover:text-status-overdue/80"
                            >
                              <Trash2 className="h-5 w-5" />
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex justify-center items-center h-32">
              <p>Nenhum cardápio cadastrado</p>
            </div>
          )}
        </CardContent>
      </Card>

      {isModalOpen && (
        <AddEditCanteenModal
          open={isModalOpen}
          onClose={closeModal}
          onSave={onMenuSaved}
          menu={currentMenu}
          services={upcomingServices || []}
        />
      )}
    </section>
  );
}
