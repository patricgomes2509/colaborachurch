import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { formatDate } from "@/lib/utils";
import { DashboardData } from "@/lib/types";
import { Clock, Bell, Calendar, CheckSquare } from "lucide-react";

interface DashboardOverviewProps {
  data: DashboardData;
}

export default function DashboardOverview({ data }: DashboardOverviewProps) {
  const { upcomingServices, pendingTasks, overdueTasks, userSchedules, accessibleMinistries } = data;
  
  // Get next service
  const nextService = upcomingServices && upcomingServices.length > 0 ? upcomingServices[0] : null;

  return (
    <div className="mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Next Service Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-neutral-dark/70">Próximo Culto</p>
                <h3 className="text-lg font-semibold">
                  {nextService 
                    ? `${formatDate(nextService.date, "dd/MM")}, ${nextService.dayOfWeek}`
                    : "Nenhum culto programado"}
                </h3>
                {nextService && (
                  <p className="text-sm mt-1">{nextService.time} - {nextService.name}</p>
                )}
              </div>
              <div className="h-10 w-10 rounded-full bg-ministry-louvor flex items-center justify-center">
                <Clock className="h-5 w-5 text-primary" />
              </div>
            </div>
            
            {nextService && (
              <div className="mt-4 pt-3 border-t">
                <div className="flex text-sm">
                  <div className="mr-4">
                    <span className="block text-neutral-dark/70">Status</span>
                    <span className="font-medium text-status-pending">Pendente</span>
                  </div>
                  <div>
                    <span className="block text-neutral-dark/70">Equipes</span>
                    <span className="font-medium">Louvor, Mídia, Obreiros</span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pending Tasks Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-neutral-dark/70">Tarefas Pendentes</p>
                <h3 className="text-lg font-semibold">{pendingTasks + overdueTasks} tarefas</h3>
                <p className="text-sm mt-1">{overdueTasks} com prioridade alta</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-status-pending/20 flex items-center justify-center">
                <CheckSquare className="h-5 w-5 text-status-pending" />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t">
              <div className="text-sm">
                <span className="block text-neutral-dark/70">Distribuição</span>
                <div className="mt-2 flex items-center">
                  <Progress 
                    value={pendingTasks > 0 ? (pendingTasks / (pendingTasks + overdueTasks)) * 100 : 0} 
                    className="h-2 bg-neutral-medium" 
                  />
                  <span className="ml-2 text-neutral-dark">
                    {pendingTasks > 0 ? Math.round((pendingTasks / (pendingTasks + overdueTasks)) * 100) : 0}%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Schedules Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-neutral-dark/70">Minhas Escalas</p>
                <h3 className="text-lg font-semibold">{userSchedules?.length || 0} escalas</h3>
                {userSchedules && userSchedules.length > 0 && userSchedules[0].service && (
                  <p className="text-sm mt-1">
                    Próxima: {formatDate(userSchedules[0].service.date, "dd/MM")}
                  </p>
                )}
              </div>
              <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
            </div>
            
            <div className="mt-4 pt-3 border-t">
              <div className="text-sm grid grid-cols-3 gap-2">
                {userSchedules?.slice(0, 3).map((schedule, index) => (
                  <div 
                    key={schedule.id} 
                    className={`flex flex-col items-center p-1 rounded ${
                      index === 0 ? "bg-primary/10" : "bg-neutral-medium/50"
                    }`}
                  >
                    {schedule.service && (
                      <>
                        <span className="font-medium">{formatDate(schedule.service.date, "dd/MM")}</span>
                        <span className="text-xs text-neutral-dark/70">
                          {schedule.service.dayOfWeek.slice(0, 3)}
                        </span>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notifications Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-neutral-dark/70">Notificações</p>
                <h3 className="text-lg font-semibold">3 não lidas</h3>
                <p className="text-sm mt-1">Última há 23min</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-secondary/20 flex items-center justify-center">
                <Bell className="h-5 w-5 text-secondary" />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t">
              <div className="text-sm">
                <div className="flex items-center text-status-pending">
                  <div className="w-1 h-4 bg-status-pending rounded-full mr-2"></div>
                  <span>Alteração na escala de domingo</span>
                </div>
                <div className="flex items-center mt-1 text-neutral-dark">
                  <div className="w-1 h-4 bg-neutral-dark/30 rounded-full mr-2"></div>
                  <span>Nova tarefa: Preparar slides</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ministry Access Section */}
      {accessibleMinistries && accessibleMinistries.length > 0 && (
        <Card className="mt-6">
          <CardContent className="p-5">
            <h3 className="font-semibold mb-4">Ministérios que você pode visualizar</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {accessibleMinistries.map((ministry) => (
                <div 
                  key={ministry.id} 
                  className={`border rounded-lg p-3 bg-ministry-${ministry.slug}`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{ministry.name}</h4>
                    <span className="text-xs bg-white px-2 py-0.5 rounded text-neutral-dark">
                      {ministry.canEdit ? "Edição permitida" : "Somente leitura"}
                    </span>
                  </div>
                  <p className="text-sm mt-2">
                    Você tem acesso para visualizar as escalas deste ministério.
                  </p>
                  <div className="mt-3 text-right">
                    <Link href={`/ministry/${ministry.slug}`}>
                      <a className="text-sm text-primary font-medium">Visualizar</a>
                    </Link>
                  </div>
                </div>
              ))}

              <div className="border rounded-lg p-3 bg-neutral-light/50">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Entenda as permissões</h4>
                </div>
                <p className="text-sm mt-2">
                  Como membro de um ministério, você tem acesso de visualização às escalas de outros ministérios conforme as regras de visualização entre ministérios.
                </p>
                <div className="mt-3 text-right">
                  <Link href="#">
                    <a className="text-sm text-primary font-medium">Saiba mais</a>
                  </Link>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
