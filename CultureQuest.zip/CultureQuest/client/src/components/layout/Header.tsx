import { useAuth } from "@/contexts/AuthContext";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import { Sun, Moon, Bell } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

interface HeaderProps {
  title?: string;
}

export default function Header({ title }: HeaderProps) {
  const { user } = useAuth();
  const [darkMode, setDarkMode] = useState(false);
  
  // Buscar notificações não lidas (implementação simulada)
  const unreadNotifications = 3;
  
  // Alternar tema claro/escuro
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    // Implementação real mudaria o tema no documento
  };

  return (
    <header className="sticky top-0 z-10 border-b border-neutral-light bg-white shadow-sm">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6 md:px-8">
        <div>
          {title && (
            <h1 className="text-lg font-semibold text-neutral-dark">{title}</h1>
          )}
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Botão de tema */}
          <button 
            onClick={toggleDarkMode}
            className="rounded-full p-2 hover:bg-neutral-light"
          >
            {darkMode ? (
              <Sun className="h-5 w-5 text-gray-600" />
            ) : (
              <Moon className="h-5 w-5 text-gray-600" />
            )}
          </button>
          
          {/* Notificações */}
          <button className="relative rounded-full p-2 hover:bg-neutral-light">
            <Bell className="h-5 w-5 text-gray-600" />
            {unreadNotifications > 0 && (
              <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-status-overdue text-xs text-white flex items-center justify-center">
                {unreadNotifications}
              </span>
            )}
          </button>
          
          {/* Perfil do usuário */}
          <div className="flex items-center space-x-1">
            {user && (
              <>
                <div className="hidden md:block text-right mr-2">
                  <p className="text-sm font-medium text-neutral-dark">{user.fullName}</p>
                  <p className="text-xs text-gray-500">
                    {user.role === "leader" ? "Líder" : "Voluntário"}
                  </p>
                </div>
                <InitialsAvatar name={user.fullName} size="sm" />
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}