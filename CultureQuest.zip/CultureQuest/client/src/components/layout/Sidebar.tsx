import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Ministry } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import { roleLabels } from "@/lib/types";
import {
  Music,
  Book,
  Video,
  Users,
  Home,
  Coffee,
  School,
  UserCheck,
  Settings,
  LogOut,
  CheckSquare,
  BookOpen,
  Menu,
  X,
  Bell,
  MessageSquare
} from "lucide-react";

const getMinistryIcon = (slug: string) => {
  switch (slug) {
    case "louvor":
      return <Music className="h-5 w-5 mr-3" />;
    case "pregadores":
      return <Book className="h-5 w-5 mr-3" />;
    case "midia":
      return <Video className="h-5 w-5 mr-3" />;
    case "kids":
      return <Users className="h-5 w-5 mr-3" />;
    case "obreiros":
      return <UserCheck className="h-5 w-5 mr-3" />;
    case "cantina":
      return <Coffee className="h-5 w-5 mr-3" />;
    case "ebd":
      return <School className="h-5 w-5 mr-3" />;
    case "recepcao":
      return <Users className="h-5 w-5 mr-3" />;
    default:
      return <Home className="h-5 w-5 mr-3" />;
  }
};

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const { data: ministries } = useQuery<Ministry[]>({
    queryKey: ['/api/ministries'],
  });

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById("sidebar");
      const menuButton = document.getElementById("openSidebar");
      
      if (
        sidebar &&
        menuButton &&
        !sidebar.contains(event.target as Node) &&
        !menuButton.contains(event.target as Node) &&
        window.innerWidth < 768
      ) {
        setIsSidebarOpen(false);
      }
    };

    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      window.location.href = "/login";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const userMinistry = ministries?.find(m => m.id === user?.ministryId);

  return (
    <>
      {/* Mobile sidebar toggle button */}
      <button
        id="openSidebar"
        className="md:hidden fixed top-3 left-4 z-30 p-2 text-white"
        onClick={toggleSidebar}
      >
        <Menu className="h-6 w-6" />
      </button>

      {/* Sidebar */}
      <div
        id="sidebar"
        className={`fixed inset-y-0 left-0 z-50 transform ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:relative md:translate-x-0 transition duration-200 ease-in-out md:flex md:flex-col md:justify-between md:w-64 bg-sidebar shadow-lg md:shadow-md`}
      >
        <div>
          <div className="p-4 border-b border-sidebar-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <img src="https://github.com/patrickgomes/igrejaviva/raw/main/flame-svg.svg" alt="Chama" className="h-8 w-8 mr-2" />
                <h1 className="text-xl font-bold text-white font-montserrat tracking-wider">COLABORACHURCH</h1>
              </div>
              <button
                className="md:hidden p-2 rounded-md text-white hover:bg-sidebar-border"
                onClick={closeSidebar}
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </div>

          <div className="p-4">
            {/* Menu Principal */}
            <nav className="space-y-1">
              <Link href="/cultos">
                <div 
                  className={`flex items-center px-3 py-2 rounded-md cursor-pointer ${
                    location === "/cultos" ? "bg-white text-sidebar" : "hover:bg-[#0f8559] text-white"
                  }`}
                  onClick={closeSidebar}
                >
                  <Home className="h-5 w-5 mr-3" />
                  <span>CULTOS</span>
                </div>
              </Link>

              <Link href="/escalas">
                <div 
                  className={`flex items-center px-3 py-2 rounded-md cursor-pointer ${
                    location === "/escalas" ? "bg-white text-sidebar" : "hover:bg-[#0f8559] text-white"
                  }`}
                  onClick={closeSidebar}
                >
                  <Users className="h-5 w-5 mr-3" />
                  <span>ESCALAS</span>
                </div>
              </Link>

              <Link href="/tarefas">
                <div 
                  className={`flex items-center px-3 py-2 rounded-md cursor-pointer ${
                    location === "/tarefas" ? "bg-white text-sidebar" : "hover:bg-[#0f8559] text-white"
                  }`}
                  onClick={closeSidebar}
                >
                  <CheckSquare className="h-5 w-5 mr-3" />
                  <span>TAREFAS COLABORATIVAS</span>
                </div>
              </Link>
              
              <Link href="/cardapio">
                <div 
                  className={`flex items-center px-3 py-2 rounded-md cursor-pointer ${
                    location === "/cardapio" ? "bg-white text-sidebar" : "hover:bg-[#0f8559] text-white"
                  }`}
                  onClick={closeSidebar}
                >
                  <Coffee className="h-5 w-5 mr-3" />
                  <span>CARDÁPIO CANTINA</span>
                </div>
              </Link>
              
              <Link href="/chat">
                <div 
                  className={`flex items-center px-3 py-2 rounded-md cursor-pointer ${
                    location === "/chat" ? "bg-white text-sidebar" : "hover:bg-[#0f8559] text-white"
                  }`}
                  onClick={closeSidebar}
                >
                  <MessageSquare className="h-5 w-5 mr-3" />
                  <span>CHAT</span>
                </div>
              </Link>

              {/* Ministry Links - Para visualização contextual */}
              <div className="mt-4 pt-4 border-t border-sidebar-border">
                <h3 className="text-xs font-semibold text-white/70 mb-2 uppercase px-3">Ministérios</h3>
                {ministries?.map((ministry) => {
                  // Check if this is the user's ministry or one they have access to
                  const isUserMinistry = user?.ministryId === ministry.id;
                  const isAccessible = true; // In a real app, we would check permissions here

                  return (
                    <Link key={ministry.id} href={`/ministry/${ministry.slug}`}>
                      <div 
                        className={`flex items-center px-3 py-2 rounded-md cursor-pointer ${
                          location === `/ministry/${ministry.slug}`
                            ? "bg-white text-sidebar"
                            : "hover:bg-[#0f8559] text-white"
                        } ${!isUserMinistry && !isAccessible ? "opacity-70" : ""}`}
                        onClick={closeSidebar}
                      >
                        <div className={`w-1 h-5 bg-white rounded-full mr-2`}></div>
                        <span>{ministry.name}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </nav>
          </div>
        </div>

        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center px-3 py-2 mb-2">
            {user && (
              <div className="flex items-center space-x-2">
                <InitialsAvatar name={user.fullName} size="sm" className="bg-white text-sidebar" />
                <div>
                  <p className="font-medium text-white text-sm">{user.fullName}</p>
                  <p className="text-xs text-white/70">
                    {roleLabels[user.role]} - {userMinistry?.name}
                  </p>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex items-center justify-between mt-4">
            <Link href="/settings">
              <div
                className="flex items-center px-3 py-2 rounded-md cursor-pointer hover:bg-[#0f8559] text-white"
                onClick={closeSidebar}
              >
                <Settings className="h-5 w-5" />
                <span className="sr-only">Configurações</span>
              </div>
            </Link>
            
            <Link href="/notifications">
              <div
                className="flex items-center px-3 py-2 rounded-md cursor-pointer hover:bg-[#0f8559] text-white"
                onClick={closeSidebar}
              >
                <Bell className="h-5 w-5" />
                <span className="sr-only">Notificações</span>
              </div>
            </Link>
            
            <div
              onClick={handleLogout}
              className="flex items-center px-3 py-2 rounded-md cursor-pointer hover:bg-[#0f8559] text-white"
            >
              <LogOut className="h-5 w-5" />
              <span className="sr-only">Sair</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
