import { useState, useEffect } from "react";
import { useQuery, useMutation, QueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Schedule, InsertSchedule, insertScheduleSchema, User, Service } from "@shared/schema";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusIcon, TrashIcon } from "lucide-react";
import { formatDate } from "@/lib/utils";

// Estender o esquema do schedule para validação
const scheduleFormSchema = insertScheduleSchema.extend({
  members: z.array(
    z.object({
      userId: z.number().optional(),
      name: z.string().min(1, "Nome é obrigatório"),
      role: z.string().min(1, "Função é obrigatória")
    })
  ).optional()
});

type ScheduleFormValues = z.infer<typeof scheduleFormSchema>;

interface AddEditScheduleModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  ministryId: number;
  schedule?: Schedule | null;
}

export default function AddEditScheduleModal({
  open,
  onClose,
  onSave,
  ministryId,
  schedule
}: AddEditScheduleModalProps) {
  const { toast } = useToast();
  const [selectedServiceId, setSelectedServiceId] = useState<number | undefined>(schedule?.serviceId);

  // Obter serviços
  const { data: services } = useQuery({
    queryKey: ["/api/services/upcoming"],
    select: (data: Service[]) => data
  });

  // Obter usuários do ministério
  const { data: ministryUsers } = useQuery({
    queryKey: [`/api/ministries/${ministryId}/users`],
    select: (data: User[]) => data
  });

  // Inicializar formulário com valores padrão
  const form = useForm<ScheduleFormValues>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      serviceId: schedule?.serviceId || undefined,
      ministryId: ministryId,
      leaderId: schedule?.leaderId || undefined,
      members: schedule?.members || [{
        userId: undefined,
        name: "",
        role: ""
      }],
      status: schedule?.status || "pending"
    }
  });

  // Configurar field array para membros
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "members"
  });

  // Mutação para criar ou atualizar escala
  const mutation = useMutation({
    mutationFn: async (data: InsertSchedule) => {
      if (schedule) {
        // Atualizar escala existente
        return apiRequest("PUT", `/api/schedules/${schedule.id}`, data);
      } else {
        // Criar nova escala
        return apiRequest("POST", `/api/ministries/${ministryId}/schedules`, data);
      }
    },
    onSuccess: () => {
      toast({
        title: schedule ? "Escala atualizada" : "Escala criada",
        description: schedule 
          ? "A escala foi atualizada com sucesso" 
          : "A escala foi criada com sucesso",
      });
      onSave();
    },
    onError: (error) => {
      console.error("Error saving schedule:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar a escala",
        variant: "destructive",
      });
    },
  });

  // Atualizar o serviço selecionado quando o formulário mudar
  useEffect(() => {
    const serviceId = form.watch("serviceId");
    if (serviceId) {
      setSelectedServiceId(serviceId);
    }
  }, [form.watch("serviceId")]);

  // Função para adicionar novo membro
  const addMember = () => {
    append({ userId: undefined, name: "", role: "" });
  };

  // Manipular submissão do formulário
  const onSubmit = (data: ScheduleFormValues) => {
    mutation.mutate(data as InsertSchedule);
  };

  // Obter detalhes do serviço selecionado
  const selectedService = services?.find(s => s.id === selectedServiceId);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {schedule ? "Editar Escala" : "Criar Nova Escala"}
          </DialogTitle>
          <DialogDescription>
            Preencha os detalhes da escala e adicione os voluntários com suas respectivas funções.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              {/* Serviço */}
              <FormField
                control={form.control}
                name="serviceId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Culto</FormLabel>
                    <Select
                      disabled={!!schedule}
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um culto" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {services?.map((service) => (
                          <SelectItem key={service.id} value={service.id.toString()}>
                            {service.name} - {formatDate(service.date, "dd/MM/yyyy")} {service.time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Líder Responsável */}
              <FormField
                control={form.control}
                name="leaderId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Líder Responsável</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um líder" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {ministryUsers?.filter(user => user.role === "leader").map((user) => (
                          <SelectItem key={user.id} value={user.id.toString()}>
                            {user.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Status */}
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="pending">Pendente</SelectItem>
                        <SelectItem value="completed">Concluído</SelectItem>
                        <SelectItem value="cancelled">Cancelado</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Membros e funções */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-medium">Voluntários e Funções</h3>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    onClick={addMember}
                  >
                    <PlusIcon className="h-4 w-4 mr-1" /> Adicionar
                  </Button>
                </div>

                {fields.map((field, index) => (
                  <div key={field.id} className="flex flex-col gap-2 p-3 border rounded-md relative">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 h-6 w-6"
                      onClick={() => remove(index)}
                    >
                      <TrashIcon className="h-4 w-4" />
                    </Button>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Nome do voluntário */}
                      <FormField
                        control={form.control}
                        name={`members.${index}.name`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Nome do voluntário" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Função/Papel */}
                      <FormField
                        control={form.control}
                        name={`members.${index}.role`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Função</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Ex: Bateria, Vocal, Som..." />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Usuário do sistema (opcional) */}
                      <FormField
                        control={form.control}
                        name={`members.${index}.userId`}
                        render={({ field }) => (
                          <FormItem className="md:col-span-2">
                            <FormLabel>Usuário do Sistema (opcional)</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(value === "0" ? undefined : parseInt(value))}
                              defaultValue={field.value?.toString() || "0"}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Selecione um usuário (opcional)" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="0">Nenhum</SelectItem>
                                {ministryUsers?.map((user) => (
                                  <SelectItem key={user.id} value={user.id.toString()}>
                                    {user.fullName}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                ))}

                {fields.length === 0 && (
                  <div className="text-center py-4 border rounded-md text-gray-500">
                    Nenhum voluntário adicionado. Clique em "Adicionar" para incluir.
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Salvando..." : "Salvar"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}