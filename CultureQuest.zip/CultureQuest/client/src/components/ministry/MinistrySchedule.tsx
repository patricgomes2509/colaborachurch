import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Schedule, Service, User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatDate, getAvatarInitials } from "@/lib/utils";
import { ScheduleWithService, statusLabels, statusColorMap } from "@/lib/types";
import { Edit, Trash2, CalendarPlus } from "lucide-react";
import AddEditScheduleModal from "./AddEditScheduleModal";

interface MinistryScheduleProps {
  ministryId: number;
}

export default function MinistrySchedule({ ministryId }: MinistryScheduleProps) {
  const { user } = useAuth();
  const isLeader = user?.role === "leader" && user?.ministryId === ministryId;
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentSchedule, setCurrentSchedule] = useState<ScheduleWithService | null>(null);
  
  // Fetch schedules for this ministry
  const { data: schedules, isLoading, refetch } = useQuery<ScheduleWithService[]>({
    queryKey: [`/api/ministries/${ministryId}/schedules`],
  });

  const handleNewSchedule = () => {
    setCurrentSchedule(null);
    setIsModalOpen(true);
  };

  const handleEditSchedule = (schedule: ScheduleWithService) => {
    setCurrentSchedule(schedule);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentSchedule(null);
  };

  const onScheduleSaved = () => {
    refetch();
    closeModal();
  };

  return (
    <section id="ministry-schedule-section" className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="w-2 h-8 bg-primary rounded-full mr-3"></div>
          <h2 className="text-xl font-bold font-montserrat">Escalas</h2>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="link"
            className="text-sm font-medium text-primary hover:text-primary-dark"
          >
            Ver todas escalas
          </Button>
          
          {isLeader && (
            <Button
              size="sm"
              className="flex items-center text-sm bg-primary text-white px-3 py-1 rounded-md hover:bg-primary-dark"
              onClick={handleNewSchedule}
            >
              <CalendarPlus className="h-4 w-4 mr-1" />
              Nova Escala
            </Button>
          )}
        </div>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <div className="px-4 py-3 border-b">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
              <h3 className="font-semibold">Escalas</h3>
              <div className="flex items-center mt-2 sm:mt-0">
                <span className="text-sm mr-2">Filtrar por:</span>
                <select className="text-sm border rounded-md px-2 py-1">
                  <option>Todos os cultos</option>
                  <option>Domingo</option>
                  <option>Quarta-feira</option>
                  <option>Especial</option>
                </select>
              </div>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-32">
              <p>Carregando escalas...</p>
            </div>
          ) : schedules?.length ? (
            <div className="overflow-x-auto">
              <Table className="min-w-full divide-y divide-neutral-medium">
                <TableHeader className="bg-neutral-light">
                  <TableRow>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-neutral-dark uppercase tracking-wider">Data</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-neutral-dark uppercase tracking-wider">Culto</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-neutral-dark uppercase tracking-wider">Equipe</TableHead>
                    <TableHead className="px-6 py-3 text-left text-xs font-medium text-neutral-dark uppercase tracking-wider">Status</TableHead>
                    {isLeader && (
                      <TableHead className="px-6 py-3 text-left text-xs font-medium text-neutral-dark uppercase tracking-wider">Ações</TableHead>
                    )}
                  </TableRow>
                </TableHeader>
                <TableBody className="bg-white divide-y divide-neutral-medium">
                  {schedules.map((schedule) => (
                    <TableRow key={schedule.id} className="hover:bg-neutral-light/50">
                      <TableCell className="px-6 py-4 whitespace-nowrap" data-label="Data">
                        {schedule.service && (
                          <>
                            <div className="text-sm font-medium">
                              {formatDate(schedule.service.date)}
                            </div>
                            <div className="text-xs text-neutral-dark">
                              {schedule.service.dayOfWeek}
                            </div>
                          </>
                        )}
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap" data-label="Culto">
                        {schedule.service && (
                          <>
                            <div className="text-sm">{schedule.service.name}</div>
                            <div className="text-xs text-neutral-dark">{schedule.service.time}</div>
                          </>
                        )}
                      </TableCell>
                      <TableCell className="px-6 py-4" data-label="Equipe">
                        <div className="text-sm">
                          {schedule.leaderId && (
                            <span className="font-medium">Líder: {schedule.leaderId}</span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {schedule.members?.map((member, index) => (
                            <span 
                              key={index}
                              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-neutral-light"
                            >
                              {member.role}: {member.userId}
                            </span>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4 whitespace-nowrap" data-label="Status">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorMap[schedule.status]}`}>
                          {statusLabels[schedule.status]}
                        </span>
                      </TableCell>
                      
                      {isLeader && (
                        <TableCell className="px-6 py-4 whitespace-nowrap text-sm" data-label="Ações">
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-primary hover:text-primary-dark"
                              onClick={() => handleEditSchedule(schedule)}
                            >
                              <Edit className="h-5 w-5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-status-overdue hover:text-status-overdue/80"
                            >
                              <Trash2 className="h-5 w-5" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex justify-center items-center h-32">
              <p>Nenhuma escala encontrada</p>
            </div>
          )}
          
          {schedules?.length > 0 && (
            <div className="px-4 py-3 border-t">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                <div className="text-sm text-neutral-dark">
                  Mostrando {schedules.length} escalas
                </div>
                {schedules.length > 10 && (
                  <div className="inline-flex mt-2 sm:mt-0">
                    <Button variant="outline" size="sm" className="px-3 py-1 rounded-l text-sm font-medium">
                      Anterior
                    </Button>
                    <Button 
                      variant="default" 
                      size="sm" 
                      className="px-3 py-1 rounded-none text-sm font-medium bg-primary text-white"
                    >
                      1
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="px-3 py-1 rounded-none text-sm font-medium"
                    >
                      2
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="px-3 py-1 rounded-none text-sm font-medium"
                    >
                      3
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="px-3 py-1 rounded-r text-sm font-medium"
                    >
                      Próximo
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {isModalOpen && (
        <AddEditScheduleModal 
          open={isModalOpen} 
          onClose={closeModal} 
          onSave={onScheduleSaved} 
          ministryId={ministryId}
          schedule={currentSchedule}
        />
      )}
    </section>
  );
}
