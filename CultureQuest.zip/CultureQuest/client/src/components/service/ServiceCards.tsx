import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, isBefore, isAfter, parseISO, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Service, Schedule } from "@shared/schema";
import { formatDate } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { PlusIcon, ChevronDownIcon, ChevronUpIcon, CalendarIcon, ShieldAlertIcon } from "lucide-react";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import AddEditScheduleModal from "../ministry/AddEditScheduleModal";
import { usePermissions } from "@/hooks/use-permissions";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface ServiceCardsProps {
  ministryId: number;
}

export function ServiceCards({ ministryId }: ServiceCardsProps) {
  const [openServiceId, setOpenServiceId] = useState<number | null>(null);
  const [isAddScheduleModalOpen, setIsAddScheduleModalOpen] = useState(false);
  const [selectedServiceId, setSelectedServiceId] = useState<number | null>(null);
  
  // Usar o hook de permissões para verificar quais ações o usuário pode realizar
  const { isLeader, canCreateSchedules, canEditSchedules } = usePermissions();

  // Fetch upcoming services
  const { data: services, isLoading: servicesLoading } = useQuery({
    queryKey: ["/api/services/upcoming", 10],
    select: (data: Service[]) => data
  });

  // Fetch schedules for current ministry
  const { data: schedules, isLoading: schedulesLoading, refetch: refetchSchedules } = useQuery({
    queryKey: [`/api/ministries/${ministryId}/schedules`],
    select: (data: Schedule[]) => data
  });

  // Get service status based on date
  const getServiceStatus = (serviceDate: Date | string): 'past' | 'next' | 'future' => {
    const parsedDate = typeof serviceDate === 'string' ? parseISO(serviceDate) : serviceDate;
    const now = new Date();
    const nextDay = addDays(now, 1);

    if (isBefore(parsedDate, now)) return 'past';
    if (isAfter(parsedDate, nextDay)) return 'future';
    return 'next';
  };

  // Get background color based on service status
  const getCardColor = (status: 'past' | 'next' | 'future'): string => {
    switch (status) {
      case 'past': return 'bg-green-50 border-green-200';
      case 'next': return 'bg-white border-blue-200';
      case 'future': return 'bg-yellow-50 border-yellow-200';
      default: return 'bg-white';
    }
  };

  // Get badge color based on service status
  const getBadgeColor = (status: 'past' | 'next' | 'future'): string => {
    switch (status) {
      case 'past': return 'bg-green-100 text-green-800';
      case 'next': return 'bg-blue-100 text-blue-800';
      case 'future': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100';
    }
  };

  // Get badge text based on service status
  const getBadgeText = (status: 'past' | 'next' | 'future'): string => {
    switch (status) {
      case 'past': return 'Realizado';
      case 'next': return 'Próximo';
      case 'future': return 'Futuro';
      default: return '';
    }
  };

  // Find schedule for a specific service
  const findSchedule = (serviceId: number) => {
    return schedules?.find(schedule => schedule.serviceId === serviceId);
  };

  // Handle adding a schedule
  const handleAddSchedule = (serviceId: number) => {
    setSelectedServiceId(serviceId);
    setIsAddScheduleModalOpen(true);
  };

  // Toggle card expansion
  const toggleCard = (serviceId: number) => {
    setOpenServiceId(openServiceId === serviceId ? null : serviceId);
  };

  if (servicesLoading || schedulesLoading) {
    return <div className="text-center p-8">Carregando cultos...</div>;
  }

  if (!services || services.length === 0) {
    return <div className="text-center p-8">Nenhum culto programado.</div>;
  }

  return (
    <div className="space-y-4">
      {services.map(service => {
        const status = getServiceStatus(service.date);
        const cardColor = getCardColor(status);
        const badgeColor = getBadgeColor(status);
        const badgeText = getBadgeText(status);
        const schedule = findSchedule(service.id);
        
        return (
          <Collapsible
            key={service.id}
            open={openServiceId === service.id}
            onOpenChange={() => toggleCard(service.id)}
            className={`rounded-lg border shadow-sm ${cardColor}`}
          >
            <div className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-medium text-gray-500">
                      {typeof service.date === 'string' ? formatDate(service.date, "dd/MM/yyyy") : service.date.toLocaleDateString()} - {service.time}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold mt-1">{service.name}</h3>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={badgeColor}>{badgeText}</Badge>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="p-0 h-8 w-8">
                      {openServiceId === service.id ? (
                        <ChevronUpIcon className="h-4 w-4" />
                      ) : (
                        <ChevronDownIcon className="h-4 w-4" />
                      )}
                    </Button>
                  </CollapsibleTrigger>
                </div>
              </div>
            </div>
            
            <CollapsibleContent>
              <div className="px-4 pb-4">
                <div className="border-t my-2 border-gray-200"></div>
                
                {schedule ? (
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm">Voluntários Escalados:</h4>
                    
                    {schedule.members && schedule.members.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {schedule.members.map((member, idx) => (
                          <div key={idx} className="flex items-center gap-2 p-2 bg-white rounded border">
                            <InitialsAvatar 
                              name={member.name || "Voluntário"} 
                              size="sm" 
                            />
                            <div>
                              <div className="font-medium text-sm">{member.name}</div>
                              <div className="text-xs text-gray-500">{member.role}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500">Nenhum voluntário atribuído ainda.</p>
                    )}
                    
                    <div className="flex justify-end">
                      {canEditSchedules(ministryId) ? (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleAddSchedule(service.id)}
                        >
                          Editar Escala
                        </Button>
                      ) : (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center gap-1 px-3 py-1 text-sm text-gray-500 border rounded">
                                <ShieldAlertIcon className="h-4 w-4" />
                                <span>Somente líderes</span>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Apenas líderes podem editar escalas</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center py-4">
                    <p className="text-sm text-gray-500 mb-3">Nenhuma escala criada para este culto.</p>
                    
                    {canCreateSchedules ? (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleAddSchedule(service.id)}
                      >
                        <PlusIcon className="h-4 w-4 mr-1" /> Criar Escala
                      </Button>
                    ) : (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex items-center gap-1 px-3 py-1 text-sm text-gray-500 border rounded">
                              <ShieldAlertIcon className="h-4 w-4" />
                              <span>Somente líderes podem criar escalas</span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Contate um líder para criar uma escala para este culto</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                )}
              </div>
            </CollapsibleContent>
          </Collapsible>
        );
      })}

      {selectedServiceId && (
        <AddEditScheduleModal
          open={isAddScheduleModalOpen}
          onClose={() => setIsAddScheduleModalOpen(false)}
          onSave={() => {
            refetchSchedules();
            setIsAddScheduleModalOpen(false);
          }}
          ministryId={ministryId}
          schedule={findSchedule(selectedServiceId)}
        />
      )}
    </div>
  );
}