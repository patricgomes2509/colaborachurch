import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { InsertTask, Task, User, Priority } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import { priorityLabels } from "@/lib/types";

// Create schema for form validation
const taskSchema = z.object({
  title: z.string().min(3, "O título deve ter pelo menos 3 caracteres"),
  description: z.string().optional(),
  priority: z.enum(["high", "medium", "low"] as const),
  dueDate: z.date().optional(),
  assignees: z.array(z.number()).optional(),
});

type TaskFormValues = z.infer<typeof taskSchema>;

interface AddEditTaskModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  ministryId: number;
  task?: Task | null;
  users: User[];
}

export default function AddEditTaskModal({
  open,
  onClose,
  onSave,
  ministryId,
  task,
  users
}: AddEditTaskModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedAssignees, setSelectedAssignees] = useState<number[]>([]);

  // Initialize form with default values or task values
  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: task?.title || "",
      description: task?.description || "",
      priority: (task?.priority as Priority) || "medium",
      dueDate: task?.dueDate ? new Date(task.dueDate) : undefined,
      assignees: task?.assignees || [],
    },
  });

  // Update selected assignees when task changes
  useEffect(() => {
    if (task?.assignees) {
      setSelectedAssignees(task.assignees);
      form.setValue("assignees", task.assignees);
    } else {
      setSelectedAssignees([]);
      form.setValue("assignees", []);
    }
  }, [task, form]);

  // Create or update task mutation
  const mutation = useMutation({
    mutationFn: async (data: InsertTask) => {
      if (task) {
        // Update existing task
        return apiRequest("PUT", `/api/tasks/${task.id}`, data);
      } else {
        // Create new task
        return apiRequest("POST", `/api/ministries/${ministryId}/tasks`, data);
      }
    },
    onSuccess: () => {
      toast({
        title: task ? "Tarefa atualizada" : "Tarefa criada",
        description: task ? "A tarefa foi atualizada com sucesso" : "Nova tarefa criada com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/ministries/${ministryId}/tasks`] });
      onSave();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Falha ao ${task ? "atualizar" : "criar"} tarefa: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TaskFormValues) => {
    if (!user) return;

    const taskData: InsertTask = {
      title: data.title,
      description: data.description || "",
      ministryId,
      createdBy: task?.createdBy || user.id,
      status: task?.status || "pending",
      priority: data.priority,
      dueDate: data.dueDate,
      assignees: selectedAssignees,
    };

    mutation.mutate(taskData);
  };

  const toggleAssignee = (userId: number) => {
    setSelectedAssignees(prev => {
      if (prev.includes(userId)) {
        const newAssignees = prev.filter(id => id !== userId);
        form.setValue("assignees", newAssignees);
        return newAssignees;
      } else {
        const newAssignees = [...prev, userId];
        form.setValue("assignees", newAssignees);
        return newAssignees;
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{task ? "Editar Tarefa" : "Nova Tarefa"}</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Título</FormLabel>
                  <FormControl>
                    <Input placeholder="Título da tarefa" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Descreva a tarefa em detalhes" 
                      className="min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prioridade</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a prioridade" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="high">{priorityLabels.high}</SelectItem>
                        <SelectItem value="medium">{priorityLabels.medium}</SelectItem>
                        <SelectItem value="low">{priorityLabels.low}</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Data de Vencimento</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={`w-full pl-3 text-left font-normal ${
                              !field.value && "text-muted-foreground"
                            }`}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: ptBR })
                            ) : (
                              <span>Selecione uma data</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                          locale={ptBR}
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormItem>
              <FormLabel>Atribuir para</FormLabel>
              <div className="space-y-2 mt-2 max-h-[200px] overflow-y-auto border rounded-md p-2">
                {users
                  .filter(u => u.ministryId === ministryId)
                  .map((user) => (
                    <div 
                      key={user.id} 
                      className="flex items-center space-x-2 p-2 hover:bg-neutral-light/50 rounded-md cursor-pointer"
                      onClick={() => toggleAssignee(user.id)}
                    >
                      <Checkbox 
                        checked={selectedAssignees.includes(user.id)} 
                        onCheckedChange={() => toggleAssignee(user.id)} 
                      />
                      <div className="flex items-center space-x-2">
                        <InitialsAvatar name={user.fullName} size="sm" />
                        <span>{user.fullName}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </FormItem>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending 
                  ? (task ? "Atualizando..." : "Criando...")
                  : (task ? "Atualizar" : "Criar")
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
