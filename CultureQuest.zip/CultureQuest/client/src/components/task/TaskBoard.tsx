import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Task, User } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import TaskCard from "./TaskCard";
import AddEditTaskModal from "./AddEditTaskModal";
import { TaskWithUsers } from "@/lib/types";

interface TaskBoardProps {
  ministryId: number;
  fullView?: boolean;
}

export default function TaskBoard({ ministryId, fullView = false }: TaskBoardProps) {
  const { user } = useAuth();
  const isLeader = user?.role === "leader" && user?.ministryId === ministryId;
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState<Task | null>(null);

  // Fetch tasks for this ministry
  const { data, isLoading, refetch } = useQuery<{ tasks: Task[], users: User[] }>({
    queryKey: [`/api/ministries/${ministryId}/tasks`],
  });

  const tasks = data?.tasks || [];
  const users = data?.users || [];

  // Create task lists by status
  const pendingTasks = tasks.filter(task => {
    const dueDate = task.dueDate ? new Date(task.dueDate) : null;
    const now = new Date();
    return task.status === "pending" && (!dueDate || dueDate >= now);
  });

  const overdueTasks = tasks.filter(task => {
    const dueDate = task.dueDate ? new Date(task.dueDate) : null;
    const now = new Date();
    return task.status === "pending" && dueDate && dueDate < now;
  });

  const completedTasks = tasks.filter(task => task.status === "completed");

  // Enhance tasks with user details
  const enhanceTask = (task: Task): TaskWithUsers => {
    const createdByUser = users.find(u => u.id === task.createdBy);
    const assigneeUsers = task.assignees.map(id => users.find(u => u.id === id)).filter(Boolean) as User[];

    return {
      ...task,
      createdByUser: createdByUser ? { 
        id: createdByUser.id, 
        fullName: createdByUser.fullName, 
        role: createdByUser.role
      } : undefined,
      assigneeUsers: assigneeUsers.map(u => ({ 
        id: u.id, 
        fullName: u.fullName, 
        role: u.role
      }))
    };
  };

  const handleNewTask = () => {
    setCurrentTask(null);
    setIsModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setCurrentTask(task);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentTask(null);
  };

  const onTaskSaved = () => {
    refetch();
    closeModal();
  };

  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <div className="w-2 h-8 bg-secondary rounded-full mr-3"></div>
            <h2 className="text-xl font-bold font-montserrat">Tarefas Colaborativas</h2>
          </div>
        </div>
        <div className="flex justify-center items-center h-32">
          <p>Carregando tarefas...</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="w-2 h-8 bg-secondary rounded-full mr-3"></div>
          <h2 className="text-xl font-bold font-montserrat">Tarefas Colaborativas</h2>
        </div>
        <Button
          size="sm"
          onClick={handleNewTask}
          className="flex items-center text-sm bg-secondary text-white px-3 py-1 rounded-md hover:bg-secondary-dark"
        >
          <PlusCircle className="h-4 w-4 mr-1" />
          Nova Tarefa
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Pending Tasks Column */}
        <div>
          <h3 className="text-lg font-semibold font-montserrat mb-3 flex items-center">
            <span className="w-3 h-3 bg-status-pending rounded-full mr-2"></span>
            Pendentes
            <span className="ml-2 text-sm bg-status-pending text-white rounded-full h-5 w-5 flex items-center justify-center">
              {pendingTasks.length}
            </span>
          </h3>

          <div className="space-y-3">
            {pendingTasks.length > 0 ? (
              pendingTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={enhanceTask(task)}
                  onEdit={() => handleEditTask(task)}
                  users={users}
                  refetchTasks={refetch}
                />
              ))
            ) : (
              <Card>
                <CardContent className="p-4 text-center py-10 text-muted-foreground">
                  Não há tarefas pendentes
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Overdue Tasks Column */}
        <div>
          <h3 className="text-lg font-semibold font-montserrat mb-3 flex items-center">
            <span className="w-3 h-3 bg-status-overdue rounded-full mr-2"></span>
            Vencidas
            <span className="ml-2 text-sm bg-status-overdue text-white rounded-full h-5 w-5 flex items-center justify-center">
              {overdueTasks.length}
            </span>
          </h3>

          <div className="space-y-3">
            {overdueTasks.length > 0 ? (
              overdueTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={enhanceTask(task)}
                  onEdit={() => handleEditTask(task)}
                  users={users}
                  refetchTasks={refetch}
                />
              ))
            ) : (
              <Card>
                <CardContent className="p-4 text-center py-10 text-muted-foreground">
                  Não há tarefas vencidas
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Completed Tasks Column */}
        <div>
          <h3 className="text-lg font-semibold font-montserrat mb-3 flex items-center">
            <span className="w-3 h-3 bg-status-completed rounded-full mr-2"></span>
            Concluídas
            <span className="ml-2 text-sm bg-status-completed text-white rounded-full h-5 w-5 flex items-center justify-center">
              {completedTasks.length}
            </span>
          </h3>

          <div className="space-y-3">
            {completedTasks.length > 0 ? (
              (fullView ? completedTasks : completedTasks.slice(0, 5)).map(task => (
                <TaskCard
                  key={task.id}
                  task={enhanceTask(task)}
                  onEdit={() => handleEditTask(task)}
                  users={users}
                  refetchTasks={refetch}
                  isCompleted
                />
              ))
            ) : (
              <Card>
                <CardContent className="p-4 text-center py-10 text-muted-foreground">
                  Não há tarefas concluídas
                </CardContent>
              </Card>
            )}
            
            {!fullView && completedTasks.length > 5 && (
              <div className="text-center mt-2">
                <Button variant="link" className="text-primary">
                  Ver todas ({completedTasks.length})
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {isModalOpen && (
        <AddEditTaskModal
          open={isModalOpen}
          onClose={closeModal}
          onSave={onTaskSaved}
          ministryId={ministryId}
          task={currentTask}
          users={users}
        />
      )}
    </section>
  );
}
