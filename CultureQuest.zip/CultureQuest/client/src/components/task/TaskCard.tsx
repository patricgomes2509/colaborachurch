import { useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  Pencil, 
  Trash2, 
  CheckCircle
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import { TaskWithUsers, taskStatusColorMap, priorityLabels, priorityColorMap } from "@/lib/types";

interface TaskCardProps {
  task: TaskWithUsers;
  onEdit: () => void;
  users: User[];
  refetchTasks: () => void;
  isCompleted?: boolean;
}

export default function TaskCard({
  task,
  onEdit,
  users,
  refetchTasks,
  isCompleted = false
}: TaskCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const isUserAssigned = task.assignees.includes(user?.id || 0);
  const isTaskCreator = task.createdBy === user?.id;
  const isMinistryLeader = user?.ministryId === task.ministryId && user?.role === "leader";
  const hasEditPermission = isTaskCreator || isMinistryLeader;
  
  // Get ministry info to display badge
  const ministry = task.ministryId 
    ? { id: task.ministryId, name: "Ministério" } // This would ideally come from a ministries context or prop
    : null;

  // Update task status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      return apiRequest("PUT", `/api/tasks/${task.id}`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Tarefa atualizada",
        description: "O status da tarefa foi atualizado com sucesso"
      });
      queryClient.invalidateQueries({ queryKey: [`/api/ministries/${task.ministryId}/tasks`] });
      refetchTasks();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Falha ao atualizar tarefa: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/tasks/${task.id}`);
    },
    onSuccess: () => {
      toast({
        title: "Tarefa excluída",
        description: "A tarefa foi excluída com sucesso"
      });
      queryClient.invalidateQueries({ queryKey: [`/api/ministries/${task.ministryId}/tasks`] });
      refetchTasks();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Falha ao excluir tarefa: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleCompleteTask = () => {
    if (isUserAssigned || hasEditPermission) {
      updateStatusMutation.mutate("completed");
    }
  };
  
  const handleDeleteTask = () => {
    if (hasEditPermission) {
      deleteTaskMutation.mutate();
    }
  };
  
  const borderColorClass = isCompleted 
    ? "border-l-4 border-status-completed" 
    : task.status === "overdue" 
      ? "border-l-4 border-status-overdue" 
      : "border-l-4 border-status-pending";
  
  return (
    <Card className={`p-4 ${borderColorClass}`}>
      <div className="flex justify-between">
        <h4 className="font-medium">{task.title}</h4>
        <span className={`text-xs px-2 py-0.5 rounded bg-ministry-${ministry?.id || 'default'}`}>
          {ministry?.name || "Ministério"}
        </span>
      </div>
      <p className="text-sm text-neutral-dark mt-2">
        {task.description}
      </p>
      <div className="mt-3 flex justify-between items-center text-xs">
        {task.dueDate && (
          <span className={task.status === "overdue" ? "text-status-overdue font-medium" : ""}>
            {isCompleted && task.completedAt 
              ? `Concluída: ${formatDate(task.completedAt)}`
              : `Prazo: ${formatDate(task.dueDate)}${task.status === "overdue" ? " (Vencida)" : ""}`}
          </span>
        )}
        <span className={`px-2 py-1 rounded-full text-xs ${priorityColorMap[task.priority]}`}>
          Prioridade: {priorityLabels[task.priority]}
        </span>
      </div>
      <div className="mt-3 pt-3 border-t flex justify-between">
        <div className="flex -space-x-1">
          {task.assigneeUsers?.map((assignee) => (
            <InitialsAvatar key={assignee.id} name={assignee.fullName || ""} size="sm" />
          ))}
        </div>
        <div className="flex space-x-1">
          {hasEditPermission && (
            <Button
              variant="ghost"
              size="icon"
              className="text-primary hover:text-primary-dark p-1"
              onClick={onEdit}
            >
              <Pencil className="h-4 w-4" />
            </Button>
          )}
          
          {hasEditPermission && (
            <Button
              variant="ghost"
              size="icon"
              className="text-status-overdue hover:text-status-overdue/80 p-1"
              onClick={handleDeleteTask}
              disabled={deleteTaskMutation.isPending}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
          
          {!isCompleted && (isUserAssigned || hasEditPermission) && (
            <Button
              variant="ghost"
              size="icon"
              className="text-status-completed hover:text-status-completed/80 p-1"
              onClick={handleCompleteTask}
              disabled={updateStatusMutation.isPending}
            >
              <CheckCircle className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
