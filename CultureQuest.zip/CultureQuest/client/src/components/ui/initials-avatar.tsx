import { getAvatarInitials, getInitialsAvatarColors } from "@/lib/utils";
import { InitialsAvatarProps } from "@/lib/types";
import { cn } from "@/lib/utils";

export function InitialsAvatar({ name, size = "md", bgColor, className }: InitialsAvatarProps) {
  const initials = getAvatarInitials(name);
  const backgroundColor = bgColor || getInitialsAvatarColors(name);
  
  const sizeClasses = {
    sm: "h-8 w-8 text-xs",
    md: "h-10 w-10 text-sm",
    lg: "h-12 w-12 text-base"
  };
  
  return (
    <div 
      className={cn(
        "flex items-center justify-center rounded-full font-medium text-white",
        sizeClasses[size],
        className
      )}
      style={{ backgroundColor }}
    >
      {initials}
    </div>
  );
}