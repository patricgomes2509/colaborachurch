import { useAuth } from "@/contexts/AuthContext";

export function usePermissions() {
  const { user } = useAuth();
  
  // Verificar se o usuário é um líder (admin)
  const isLeader = user?.role === "leader";
  
  // Verificar se o usuário pertence a um ministério específico
  const isInMinistry = (ministryId: number | undefined | null) => {
    if (!user || !ministryId) return false;
    return user.ministryId === ministryId;
  };
  
  // Verificar se o usuário pode criar escalas (precisa ser líder)
  const canCreateSchedules = isLeader;
  
  // Verificar se o usuário pode editar escalas do ministério
  const canEditSchedules = (ministryId: number | undefined | null) => {
    return isLeader && isInMinistry(ministryId);
  };
  
  // Verificar se o usuário pode criar tarefas (precisa ser líder)
  const canCreateTasks = isLeader;
  
  // Verificar se o usuário pode editar tarefas
  const canEditTasks = (ministryId: number | undefined | null) => {
    return isLeader && isInMinistry(ministryId);
  };
  
  // Verificar se o usuário pode marcar uma tarefa como concluída
  // (qualquer voluntário do ministério pode)
  const canCompleteTask = (ministryId: number | undefined | null, assigneeIds: number[] | null) => {
    if (!user || !ministryId) return false;
    
    // Se é o líder do ministério
    if (isLeader && isInMinistry(ministryId)) return true;
    
    // Se é um voluntário do ministério e está atribuído à tarefa
    if (assigneeIds && assigneeIds.includes(user.id)) return true;
    
    return false;
  };
  
  return {
    isLeader,
    isInMinistry,
    canCreateSchedules,
    canEditSchedules,
    canCreateTasks,
    canEditTasks,
    canCompleteTask
  };
}