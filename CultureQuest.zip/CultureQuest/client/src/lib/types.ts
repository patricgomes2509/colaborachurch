import { 
  User, 
  Ministry, 
  Service, 
  Schedule, 
  Task,
  Contestation,
  CanteenMenu,
  AccessRule,
  RoleType,
  ServiceStatus,
  TaskStatus,
  Priority
} from "@shared/schema";

// Frontend specific types
export interface ScheduleWithService extends Schedule {
  service?: Service;
}

export interface TaskWithUsers extends Task {
  createdByUser?: Partial<User>;
  assigneeUsers?: Partial<User>[];
}

export interface CanteenMenuWithDetails extends CanteenMenu {
  service?: Service;
  responsibleName?: string;
}

export interface MinistryWithAccess extends Ministry {
  canEdit: boolean;
}

export interface DashboardData {
  upcomingServices: Service[];
  pendingTasks: number;
  overdueTasks: number;
  userSchedules: ScheduleWithService[];
  accessibleMinistries: MinistryWithAccess[];
}

export const statusLabels: Record<ServiceStatus, string> = {
  pending: "Pendente",
  completed: "Realizado",
  cancelled: "Cancelado"
};

export const taskStatusLabels: Record<TaskStatus, string> = {
  pending: "Pendente",
  overdue: "Vencida",
  completed: "Concluída"
};

export const priorityLabels: Record<Priority, string> = {
  high: "Alta",
  medium: "Média",
  low: "Baixa"
};

export const roleLabels: Record<RoleType, string> = {
  leader: "Líder",
  volunteer: "Voluntário"
};

export const weekDayLabels: Record<string, string> = {
  "Sunday": "Domingo",
  "Monday": "Segunda-feira",
  "Tuesday": "Terça-feira",
  "Wednesday": "Quarta-feira",
  "Thursday": "Quinta-feira",
  "Friday": "Sexta-feira",
  "Saturday": "Sábado"
};

export const statusColorMap: Record<ServiceStatus, string> = {
  pending: "bg-status-pending text-white",
  completed: "bg-status-completed text-white",
  cancelled: "bg-status-overdue text-white"
};

export const taskStatusColorMap: Record<TaskStatus, string> = {
  pending: "bg-status-pending text-white",
  overdue: "bg-status-overdue text-white",
  completed: "bg-status-completed text-white"
};

export const priorityColorMap: Record<Priority, string> = {
  high: "bg-status-overdue text-white",
  medium: "bg-status-pending text-white",
  low: "bg-blue-500 text-white"
};

export type InitialsAvatarProps = {
  name: string;
  size?: 'sm' | 'md' | 'lg';
  bgColor?: string;
  className?: string;
};
