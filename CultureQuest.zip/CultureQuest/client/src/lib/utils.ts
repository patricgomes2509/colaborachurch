import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date, formatStr: string = "dd/MM/yyyy"): string {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  return format(parsedDate, formatStr, { locale: ptBR });
}

export function getAvatarInitials(name: string): string {
  if (!name) return "";
  
  const names = name.split(" ");
  if (names.length === 1) {
    return names[0].substring(0, 2).toUpperCase();
  } else {
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  }
}

export const getInitialsAvatarColors = (name: string): string => {
  const colors = [
    "bg-primary",
    "bg-secondary",
    "bg-accent",
    "bg-status-completed",
    "bg-status-pending",
    "bg-primary-dark",
    "bg-secondary-dark",
  ];
  
  // Generate a deterministic index based on the name
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  hash = Math.abs(hash);
  const index = hash % colors.length;
  
  return colors[index];
};

export function getDayOfWeekPortuguese(date: Date): string {
  const weekDays = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
  return weekDays[date.getDay()];
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + "...";
}
