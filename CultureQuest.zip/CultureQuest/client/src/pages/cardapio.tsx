import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { CanteenMenu as BaseCanteenMenu, Service, Ministry } from "@shared/schema";

// Estender o tipo CanteenMenu para incluir responsibleName
interface CanteenMenu extends BaseCanteenMenu {
  responsibleName?: string;
}
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { 
  Plus, Calendar, Edit, Trash, Coffee, 
  ChevronDown, ArrowLeft, ArrowRight 
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { apiRequest } from "@/lib/queryClient";

export default function CardapioPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddMenuModalOpen, setIsAddMenuModalOpen] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState<CanteenMenu | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toLocaleString('pt-BR', { month: 'long' }).toUpperCase());
  const [currentMonthIndex, setCurrentMonthIndex] = useState<number>(new Date().getMonth());
  
  const meses = [
    'JANEIRO', 'FEVEREIRO', 'MARÇO', 'ABRIL', 'MAIO', 'JUNHO', 
    'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO'
  ];
  
  const handlePreviousMonth = () => {
    const newIndex = currentMonthIndex > 0 ? currentMonthIndex - 1 : 11;
    setCurrentMonthIndex(newIndex);
    setSelectedMonth(meses[newIndex]);
  };
  
  const handleNextMonth = () => {
    const newIndex = currentMonthIndex < 11 ? currentMonthIndex + 1 : 0;
    setCurrentMonthIndex(newIndex);
    setSelectedMonth(meses[newIndex]);
  };
  
  // Verificar se o usuário tem permissão para editar o cardápio
  const canEditMenu = user?.ministryId === 6 || user?.role === "leader"; // 6 = Cantina (assumindo)
  
  // Buscar cardápios da cantina
  const { data: canteenMenus, isLoading: menusLoading } = useQuery<CanteenMenu[]>({
    queryKey: ['/api/canteen-menus'],
  });

  // Buscar serviços/cultos
  const { data: services } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });
  
  // Filtrar cardápios pelo mês selecionado
  const filteredMenus = canteenMenus?.filter(menu => {
    const service = services?.find(s => s.id === menu.serviceId);
    if (!service) return false;
    
    const serviceMonth = new Date(service.date).getMonth();
    return serviceMonth === currentMonthIndex;
  });
  
  // Mutação para adicionar novo cardápio
  const addMenuMutation = useMutation({
    mutationFn: async (newMenu: any) => {
      return await apiRequest('/api/canteen-menus', 'POST', newMenu);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/canteen-menus'] });
      toast({
        title: "Cardápio adicionado",
        description: "Cardápio adicionado com sucesso!",
      });
      setIsAddMenuModalOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao adicionar cardápio",
        description: error.message || "Ocorreu um erro ao adicionar o cardápio.",
        variant: "destructive",
      });
    },
  });
  
  // Mutação para atualizar cardápio existente
  const updateMenuMutation = useMutation({
    mutationFn: async (updatedMenu: any) => {
      return await apiRequest(`/api/canteen-menus/${updatedMenu.id}`, 'PATCH', updatedMenu);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/canteen-menus'] });
      toast({
        title: "Cardápio atualizado",
        description: "Cardápio atualizado com sucesso!",
      });
      setIsAddMenuModalOpen(false);
      setSelectedMenu(null);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar cardápio",
        description: error.message || "Ocorreu um erro ao atualizar o cardápio.",
        variant: "destructive",
      });
    },
  });
  
  // Mutação para excluir cardápio
  const deleteMenuMutation = useMutation({
    mutationFn: async (menuId: number) => {
      return await apiRequest(`/api/canteen-menus/${menuId}`, 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/canteen-menus'] });
      toast({
        title: "Cardápio excluído",
        description: "Cardápio excluído com sucesso!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao excluir cardápio",
        description: error.message || "Ocorreu um erro ao excluir o cardápio.",
        variant: "destructive",
      });
    },
  });
  
  // Função para adicionar novo cardápio
  const handleAddMenu = () => {
    setSelectedMenu(null);
    setIsAddMenuModalOpen(true);
  };
  
  // Função para editar cardápio
  const handleEditMenu = (menu: CanteenMenu) => {
    setSelectedMenu(menu);
    setIsAddMenuModalOpen(true);
  };
  
  // Função para excluir cardápio
  const handleDeleteMenu = (menuId: number) => {
    if (confirm("Tem certeza que deseja excluir este cardápio?")) {
      deleteMenuMutation.mutate(menuId);
      
      // Enviar para o webhook
      sendMenuToWebhook({ id: menuId } as CanteenMenu, "excluir_cardapio");
    }
  };
  
  // Função para obter informações do serviço relacionado ao cardápio
  const getServiceInfo = (serviceId: number) => {
    const service = services?.find(s => s.id === serviceId);
    if (!service) return { name: "Culto não encontrado", date: new Date(), formatted: "" };
    
    return {
      name: service.name,
      date: new Date(service.date),
      formatted: `${formatDate(service.date, 'dd/MM/yyyy')} - ${service.time}`,
      dayOfWeek: service.dayOfWeek
    };
  };
  
  // Enviar cardápio para o webhook
  const sendMenuToWebhook = async (menu: CanteenMenu, operation: string) => {
    try {
      const webhookUrl = "https://patricgomes.app.n8n.cloud/webhook-test/0b93fb2d-fead-4987-8a74-10f09e732ab2";
      
      const serviceInfo = getServiceInfo(menu.serviceId);
      
      const payload = {
        tipo_operacao: operation,
        nome_ministerio: "Cantina",
        dados: {
          id: menu.id,
          culto: serviceInfo.name,
          data: serviceInfo.formatted,
          dia_semana: serviceInfo.dayOfWeek,
          itens: menu.items,
          responsavel: menu.responsibleName
        }
      };
      
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      
      if (response.ok) {
        console.log("Dados enviados com sucesso para o webhook");
      } else {
        console.error("Erro ao enviar dados para o webhook");
      }
    } catch (error) {
      console.error("Erro ao enviar dados para o webhook:", error);
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64 bg-neutral-light">
        <Header title="Cardápio da Cantina" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <div className="w-2 h-8 bg-ministry-cantina rounded-full mr-3"></div>
              <h1 className="text-2xl font-bold">CARDÁPIO DA CANTINA</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Navegação de mês */}
              <div className="flex items-center border border-ministry-cantina rounded-full px-2 py-1 bg-white">
                <button 
                  className="hover:bg-neutral-light rounded-full p-1"
                  onClick={handlePreviousMonth}
                >
                  <ArrowLeft className="h-4 w-4" />
                </button>
                
                <span className="px-2 font-medium">MÊS: {selectedMonth}</span>
                
                <button 
                  className="hover:bg-neutral-light rounded-full p-1"
                  onClick={handleNextMonth}
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              
              {/* Botão de adicionar novo cardápio (apenas para cantina) */}
              {canEditMenu && (
                <Button 
                  onClick={handleAddMenu}
                  className="bg-ministry-cantina text-white hover:bg-ministry-cantina/90"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Novo Cardápio
                </Button>
              )}
            </div>
          </div>
          
          {/* Grid de cardápios */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            {menusLoading ? (
              <div className="flex justify-center items-center h-32 col-span-full">
                <p>Carregando cardápios...</p>
              </div>
            ) : filteredMenus && filteredMenus.length > 0 ? (
              filteredMenus.map((menu) => {
                const serviceInfo = getServiceInfo(menu.serviceId);
                const isPastService = serviceInfo.date < new Date();
                
                return (
                  <Card key={menu.id} className={`border-2 ${isPastService ? 'border-status-completed' : 'border-ministry-cantina'}`}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{serviceInfo.dayOfWeek}</CardTitle>
                        
                        {canEditMenu && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <ChevronDown className="h-4 w-4" />
                                <span className="sr-only">Opções</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEditMenu(menu)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Editar Cardápio
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleDeleteMenu(menu.id)}
                                className="text-status-overdue"
                              >
                                <Trash className="h-4 w-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                      
                      <CardDescription>
                        <div className="flex items-center text-sm">
                          <Calendar className="h-4 w-4 mr-1" />
                          <span>{serviceInfo.formatted}</span>
                        </div>
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="space-y-2">
                        <h3 className="text-sm font-bold uppercase text-ministry-cantina">Cardápio:</h3>
                        <ul className="list-disc list-inside space-y-1">
                          {menu.items.map((item, index) => (
                            <li key={index} className="text-sm">{item}</li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="border-t pt-3 flex justify-between">
                      <div className="text-xs text-neutral-dark">
                        Responsável: {menu.responsibleName || "Não informado"}
                      </div>
                      <div className="flex items-center text-xs text-neutral-dark">
                        <Coffee className="h-3 w-3 mr-1" />
                        <span>Cantina</span>
                      </div>
                    </CardFooter>
                  </Card>
                );
              })
            ) : (
              <div className="flex flex-col items-center justify-center py-8 col-span-full">
                <p className="text-neutral-dark mb-4">Nenhum cardápio encontrado para o mês {selectedMonth}.</p>
                {canEditMenu && (
                  <Button 
                    onClick={handleAddMenu}
                    className="bg-ministry-cantina text-white hover:bg-ministry-cantina/90"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Adicionar Novo Cardápio
                  </Button>
                )}
              </div>
            )}
          </div>
          
          {/* Modal para adicionar/editar cardápio */}
          <Dialog open={isAddMenuModalOpen} onOpenChange={setIsAddMenuModalOpen}>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>
                  {selectedMenu ? "Editar Cardápio" : "Adicionar Novo Cardápio"}
                </DialogTitle>
                <DialogDescription>
                  Preencha os dados para {selectedMenu ? "editar o" : "adicionar um novo"} cardápio.
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="service" className="text-right font-medium">
                    Culto:
                  </label>
                  <div className="col-span-3">
                    <select
                      id="service"
                      className="w-full rounded-md border border-input bg-background px-3 py-2"
                      defaultValue={selectedMenu?.serviceId || ""}
                    >
                      <option value="">Selecione o culto</option>
                      {services?.filter(s => new Date(s.date) >= new Date()).map(service => (
                        <option key={service.id} value={service.id}>
                          {service.dayOfWeek} - {formatDate(service.date)} - {service.time}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="responsible" className="text-right font-medium">
                    Responsável:
                  </label>
                  <input
                    id="responsible"
                    className="col-span-3 rounded-md border border-input bg-background px-3 py-2"
                    defaultValue={selectedMenu?.responsibleName || ""}
                    placeholder="Nome do responsável"
                  />
                </div>
                
                <div className="grid grid-cols-4 items-start gap-4">
                  <label htmlFor="items" className="text-right font-medium mt-2">
                    Itens:
                  </label>
                  <textarea
                    id="items"
                    className="col-span-3 rounded-md border border-input bg-background px-3 py-2 h-32"
                    defaultValue={selectedMenu?.items.join("\n") || ""}
                    placeholder="Digite um item por linha"
                  ></textarea>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => setIsAddMenuModalOpen(false)}
                >
                  Cancelar
                </Button>
                <Button 
                  className="bg-ministry-cantina text-white hover:bg-ministry-cantina/90"
                  onClick={() => {
                    const serviceInput = document.getElementById("service") as HTMLSelectElement;
                    const responsibleInput = document.getElementById("responsible") as HTMLInputElement;
                    const itemsInput = document.getElementById("items") as HTMLTextAreaElement;
                    
                    const serviceId = Number(serviceInput.value);
                    const responsibleName = responsibleInput.value;
                    const items = itemsInput.value.split("\n").filter(item => item.trim() !== "");
                    
                    if (!serviceId) {
                      toast({
                        title: "Erro",
                        description: "Selecione um culto para o cardápio.",
                        variant: "destructive",
                      });
                      return;
                    }
                    
                    if (items.length === 0) {
                      toast({
                        title: "Erro",
                        description: "Adicione pelo menos um item ao cardápio.",
                        variant: "destructive",
                      });
                      return;
                    }
                    
                    const menuData = {
                      serviceId,
                      responsibleName,
                      items,
                      status: "pending" as const,
                    };
                    
                    if (selectedMenu) {
                      // Atualizar cardápio existente
                      updateMenuMutation.mutate({ 
                        id: selectedMenu.id, 
                        ...menuData 
                      });
                      
                      // Enviar para webhook
                      sendMenuToWebhook({ 
                        ...selectedMenu, 
                        ...menuData 
                      }, "atualizar_cardapio");
                    } else {
                      // Adicionar novo cardápio
                      addMenuMutation.mutate(menuData);
                      
                      // Após criação bem-sucedida, o ID estará disponível na resposta
                      // e o webhook será enviado na função de sucesso
                    }
                  }}
                >
                  {selectedMenu ? "Atualizar" : "Adicionar"} Cardápio
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h2 className="font-semibold mb-3">Sobre o Cardápio da Cantina</h2>
            <p className="text-sm text-neutral-dark mb-2">
              • O cardápio da cantina é organizado por culto, facilitando o planejamento e a divulgação.
            </p>
            <p className="text-sm text-neutral-dark mb-2">
              • Apenas membros do ministério da Cantina podem criar ou editar cardápios.
            </p>
            <p className="text-sm text-neutral-dark">
              • O ministério de Mídia tem acesso a visualizar os cardápios para fins de divulgação.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}