import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import {
  Search,
  Send,
  PaperclipIcon,
  Smile,
  MoreVertical,
  UserPlus,
  Phone,
  Video,
  ChevronLeft,
  CheckCheck,
  MessageSquare
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import { User, Ministry } from "@shared/schema";

// Tipo para as mensagens
interface Message {
  id: number;
  senderId: number;
  receiverId?: number;
  groupId?: number;
  content: string;
  timestamp: Date;
  status: "sent" | "delivered" | "read";
}

// Tipo para conversas
interface Conversation {
  id: number;
  type: "direct" | "group";
  name?: string;
  participants: number[];
  lastMessage?: {
    content: string;
    timestamp: Date;
    senderId: number;
  };
  unreadCount: number;
}

// Componente que exibe uma conversa na lista
const ConversationItem = ({ 
  conversation, 
  active, 
  onClick,
  users,
}: { 
  conversation: Conversation; 
  active: boolean; 
  onClick: () => void;
  users: User[];
}) => {
  const { user } = useAuth();
  
  // Obter informações do outro usuário ou grupo
  const getConversationInfo = () => {
    if (conversation.type === "direct") {
      // Em conversas diretas, encontrar o outro usuário
      const otherUserId = conversation.participants.find(id => id !== user?.id);
      const otherUser = users.find(u => u.id === otherUserId);
      
      return {
        name: otherUser?.fullName || "Usuário desconhecido",
        avatar: otherUser?.fullName || "U",
      };
    } else {
      // Grupo
      return {
        name: conversation.name || "Grupo sem nome",
        avatar: conversation.name?.charAt(0) || "G",
      };
    }
  };
  
  const { name, avatar } = getConversationInfo();
  
  // Formatar timestamp 
  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    
    if (now.toDateString() === messageDate.toDateString()) {
      // Hoje - mostrar apenas hora
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      // Outro dia - mostrar dia/mês
      return messageDate.toLocaleDateString([], { day: '2-digit', month: '2-digit' });
    }
  };

  return (
    <div 
      className={`flex items-center p-3 cursor-pointer hover:bg-neutral-light/50 rounded-md ${active ? 'bg-neutral-light' : ''}`}
      onClick={onClick}
    >
      <InitialsAvatar name={avatar} size="md" />
      
      <div className="ml-3 flex-1 min-w-0">
        <div className="flex justify-between items-center">
          <h4 className="font-medium truncate">{name}</h4>
          {conversation.lastMessage && (
            <span className="text-xs text-neutral-dark">
              {formatTimestamp(conversation.lastMessage.timestamp)}
            </span>
          )}
        </div>
        
        <div className="flex justify-between items-center">
          {conversation.lastMessage ? (
            <p className="text-sm text-neutral-dark truncate">
              {conversation.lastMessage.senderId === user?.id ? 'Você: ' : ''}
              {conversation.lastMessage.content}
            </p>
          ) : (
            <p className="text-sm text-neutral-dark italic">Nenhuma mensagem</p>
          )}
          
          {conversation.unreadCount > 0 && (
            <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">
              {conversation.unreadCount}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

// Componente que exibe uma mensagem no chat
const MessageBubble = ({ 
  message, 
  isOwnMessage,
  senderName,
}: { 
  message: Message; 
  isOwnMessage: boolean;
  senderName: string;
}) => {
  // Formatar timestamp da mensagem
  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return (
    <div className={`flex mb-3 ${isOwnMessage ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[70%] ${isOwnMessage ? 'order-2' : 'order-1'}`}>
        {!isOwnMessage && (
          <div className="text-xs text-neutral-dark mb-1">{senderName}</div>
        )}
        
        <div className={`p-3 rounded-lg ${isOwnMessage 
          ? 'bg-primary text-white rounded-tr-none' 
          : 'bg-white border rounded-tl-none'}`}
        >
          <p>{message.content}</p>
          <div className="flex justify-end items-center mt-1">
            <span className="text-xs opacity-70">{formattedTime}</span>
            
            {isOwnMessage && (
              <span className="ml-1">
                {message.status === 'read' ? (
                  <CheckCheck className="h-3 w-3 text-blue-400" />
                ) : message.status === 'delivered' ? (
                  <CheckCheck className="h-3 w-3" />
                ) : (
                  <CheckCheck className="h-3 w-3 opacity-50" />
                )}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Componente principal
export default function ChatPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [message, setMessage] = useState("");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isMobileView, setIsMobileView] = useState(false);
  const [showConversations, setShowConversations] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Simulação de consulta a usuários
  const { data: users } = useQuery<User[]>({
    queryKey: ['/api/users'],
    queryFn: async () => {
      // Mock data
      return [
        { id: 1, username: "joao.silva", fullName: "João Silva", role: "leader", ministryId: 1 },
        { id: 2, username: "maria.santos", fullName: "Maria Santos", role: "volunteer", ministryId: 2 },
        { id: 3, username: "pedro.oliveira", fullName: "Pedro Oliveira", role: "volunteer", ministryId: 1 },
        { id: 4, username: "ana.pereira", fullName: "Ana Pereira", role: "leader", ministryId: 3 },
        { id: 5, username: "lucas.martins", fullName: "Lucas Martins", role: "volunteer", ministryId: 4 },
      ];
    }
  });
  
  // Simulação de consulta a ministérios
  const { data: ministries } = useQuery<Ministry[]>({
    queryKey: ['/api/ministries'],
  });

  // Inicializar dados de exemplo
  useEffect(() => {
    // Dados de exemplo para conversas
    const mockConversations: Conversation[] = [
      {
        id: 1,
        type: "direct",
        participants: [1, 2],
        lastMessage: {
          content: "Olá João, tudo bem?",
          timestamp: new Date(Date.now() - 60000 * 5),
          senderId: 2
        },
        unreadCount: 1
      },
      {
        id: 2,
        type: "direct",
        participants: [1, 3],
        lastMessage: {
          content: "Você viu a escala para domingo?",
          timestamp: new Date(Date.now() - 60000 * 30),
          senderId: 1
        },
        unreadCount: 0
      },
      {
        id: 3,
        type: "group",
        name: "Ministério de Louvor",
        participants: [1, 2, 3],
        lastMessage: {
          content: "Pessoal, ensaio amanhã às 19h",
          timestamp: new Date(Date.now() - 60000 * 60 * 2),
          senderId: 1
        },
        unreadCount: 0
      },
      {
        id: 4,
        type: "direct",
        participants: [1, 4],
        lastMessage: {
          content: "Já confirmei a reserva do equipamento",
          timestamp: new Date(Date.now() - 60000 * 60 * 12),
          senderId: 4
        },
        unreadCount: 0
      }
    ];
    
    setConversations(mockConversations);
    
    // Verificar se é visualização mobile
    const checkIfMobile = () => {
      setIsMobileView(window.innerWidth < 768);
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);
  
  // Carregar mensagens quando uma conversa é selecionada
  useEffect(() => {
    if (activeConversation) {
      // Simulação de carregamento de mensagens para a conversa ativa
      const mockMessages: Message[] = [
        {
          id: 1,
          senderId: 1,
          content: "Olá! Como vai?",
          timestamp: new Date(Date.now() - 60000 * 60),
          status: "read"
        },
        {
          id: 2,
          senderId: activeConversation.type === "direct" 
            ? activeConversation.participants.find(id => id !== user?.id) || 0
            : 3,
          content: "Tudo bem! E você?",
          timestamp: new Date(Date.now() - 60000 * 58),
          status: "read"
        },
        {
          id: 3,
          senderId: 1,
          content: "Muito bem, obrigado! Precisamos acertar os detalhes do culto de domingo.",
          timestamp: new Date(Date.now() - 60000 * 55),
          status: "read"
        },
        {
          id: 4,
          senderId: activeConversation.type === "direct" 
            ? activeConversation.participants.find(id => id !== user?.id) || 0
            : 2,
          content: "Claro! Que horas você prefere marcar o ensaio?",
          timestamp: new Date(Date.now() - 60000 * 50),
          status: "read"
        },
        {
          id: 5,
          senderId: 1,
          content: "Acho que podemos fazer no sábado às 18h, o que acha?",
          timestamp: new Date(Date.now() - 60000 * 48),
          status: "delivered"
        }
      ];
      
      setMessages(mockMessages);
      
      // Marcar conversas como lidas quando selecionadas
      setConversations(prevConversations => 
        prevConversations.map(conv => 
          conv.id === activeConversation.id 
            ? { ...conv, unreadCount: 0 } 
            : conv
        )
      );
      
      // Em mobile, ocultar lista de conversas quando uma conversa é selecionada
      if (isMobileView) {
        setShowConversations(false);
      }
    }
  }, [activeConversation, user?.id, isMobileView]);
  
  // Rolar para o final quando novas mensagens chegarem
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  // Enviar mensagem
  const sendMessage = () => {
    if (!message.trim() || !activeConversation) return;
    
    // Criar nova mensagem
    const newMessage: Message = {
      id: messages.length + 1,
      senderId: user?.id || 0,
      content: message,
      timestamp: new Date(),
      status: "sent"
    };
    
    // Adicionar à lista de mensagens
    setMessages(prev => [...prev, newMessage]);
    
    // Atualizar última mensagem na conversa
    setConversations(prevConversations => 
      prevConversations.map(conv => 
        conv.id === activeConversation.id 
          ? { 
              ...conv, 
              lastMessage: {
                content: message,
                timestamp: new Date(),
                senderId: user?.id || 0
              }
            } 
          : conv
      )
    );
    
    // Limpar campo de mensagem
    setMessage("");
    
    // Simular status de entregue após 1 segundo
    setTimeout(() => {
      setMessages(prev => 
        prev.map(msg => 
          msg.id === newMessage.id 
            ? { ...msg, status: "delivered" } 
            : msg
        )
      );
      
      // Simular status de lido após 2 segundos
      setTimeout(() => {
        setMessages(prev => 
          prev.map(msg => 
            msg.id === newMessage.id 
              ? { ...msg, status: "read" } 
              : msg
          )
        );
      }, 1000);
    }, 1000);
  };
  
  // Obter nome do usuário pelo ID
  const getUserName = (userId: number) => {
    const foundUser = users?.find(u => u.id === userId);
    return foundUser?.fullName || "Usuário desconhecido";
  };
  
  // Obter informações da conversa ativa
  const getActiveConversationInfo = () => {
    if (!activeConversation) return null;
    
    if (activeConversation.type === "direct") {
      const otherUserId = activeConversation.participants.find(id => id !== user?.id);
      const otherUser = users?.find(u => u.id === otherUserId);
      
      const ministryId = otherUser?.ministryId;
      const ministry = ministries?.find(m => m.id === ministryId);
      
      return {
        name: otherUser?.fullName || "Usuário desconhecido",
        avatar: otherUser?.fullName || "U",
        subtitle: ministry ? `${ministry.name}` : "",
      };
    } else {
      // Grupo
      return {
        name: activeConversation.name || "Grupo sem nome",
        avatar: activeConversation.name?.charAt(0) || "G",
        subtitle: `${activeConversation.participants.length} membros`,
      };
    }
  };
  
  // Informações da conversa ativa
  const activeConversationInfo = getActiveConversationInfo();
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64 bg-neutral-light">
        <Header title="Chat" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8 h-[calc(100vh-64px)]">
          <div className="flex items-center mb-6">
            <div className="w-2 h-8 bg-primary rounded-full mr-3"></div>
            <h1 className="text-2xl font-bold">CHAT</h1>
          </div>
          
          <div className="flex h-[calc(100%-4rem)] bg-white rounded-lg overflow-hidden border">
            {/* Lista de Conversas */}
            {(showConversations || !isMobileView) && (
              <div className={`${isMobileView ? 'w-full' : 'w-1/3 border-r'} flex flex-col`}>
                <div className="p-3 border-b">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-dark" size={18} />
                    <Input 
                      placeholder="Buscar conversas..." 
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div className="overflow-y-auto flex-1">
                  {conversations.map(conversation => (
                    <ConversationItem 
                      key={conversation.id}
                      conversation={conversation}
                      active={activeConversation?.id === conversation.id}
                      users={users || []}
                      onClick={() => setActiveConversation(conversation)}
                    />
                  ))}
                </div>
                
                <div className="p-3 border-t">
                  <Button className="w-full">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Nova Conversa
                  </Button>
                </div>
              </div>
            )}
            
            {/* Área de Chat */}
            {(!showConversations || !isMobileView) && (
              <div className={`${isMobileView ? 'w-full' : 'w-2/3'} flex flex-col`}>
                {activeConversation ? (
                  <>
                    {/* Cabeçalho da conversa */}
                    <div className="p-3 border-b flex items-center">
                      {isMobileView && (
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="mr-2"
                          onClick={() => setShowConversations(true)}
                        >
                          <ChevronLeft />
                        </Button>
                      )}
                      
                      <InitialsAvatar 
                        name={activeConversationInfo?.avatar || ""} 
                        size="sm" 
                      />
                      
                      <div className="ml-3 flex-1">
                        <h3 className="font-medium">{activeConversationInfo?.name}</h3>
                        <p className="text-xs text-neutral-dark">
                          {activeConversationInfo?.subtitle}
                        </p>
                      </div>
                      
                      <div className="flex">
                        <Button variant="ghost" size="icon">
                          <Phone className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Video className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Área de mensagens */}
                    <div className="flex-1 overflow-y-auto p-4 bg-neutral-light/30">
                      {messages.map(message => (
                        <MessageBubble 
                          key={message.id}
                          message={message}
                          isOwnMessage={message.senderId === user?.id}
                          senderName={getUserName(message.senderId)}
                        />
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                    
                    {/* Área de input */}
                    <div className="p-3 border-t flex items-center">
                      <Button variant="ghost" size="icon">
                        <PaperclipIcon className="h-5 w-5" />
                      </Button>
                      
                      <Input 
                        placeholder="Mensagem..." 
                        className="mx-2"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                      />
                      
                      <Button variant="ghost" size="icon">
                        <Smile className="h-5 w-5" />
                      </Button>
                      
                      <Button 
                        className="ml-2" 
                        size="icon"
                        onClick={sendMessage}
                        disabled={!message.trim()}
                      >
                        <Send className="h-5 w-5" />
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full p-6 text-center">
                    <div className="bg-neutral-light rounded-full p-6 mb-4">
                      <MessageSquare className="h-12 w-12 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold mb-2">ColaboraChat</h3>
                    <p className="text-neutral-dark max-w-md">
                      Comunique-se com outros membros dos ministérios. Selecione uma conversa para começar.
                    </p>
                    {isMobileView && (
                      <Button 
                        className="mt-4"
                        onClick={() => setShowConversations(true)}
                      >
                        Ver Conversas
                      </Button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}