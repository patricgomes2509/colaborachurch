import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { ServiceForm } from "@/components/service/ServiceForm";

export default function CriarCultoPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Verificar se o usuário tem permissão para criar cultos
  // Apenas líderes podem criar cultos
  if (user && user.role !== "leader") {
    toast({
      title: "Acesso negado",
      description: "Apenas líderes podem cadastrar novos cultos",
      variant: "destructive"
    });
    setLocation("/cultos");
    return null;
  }

  const handleFormSubmit = async (data: any) => {
    try {
      setIsSubmitting(true);
      
      // Enviar dados para a API
      const response = await apiRequest("POST", "/api/services", data);
      const newService = await response.json();
      
      // Invalidar cache para refletir o novo culto
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      queryClient.invalidateQueries({ queryKey: ['/api/services/upcoming'] });
      
      toast({
        title: "Culto criado com sucesso",
        description: `O culto ${newService.name} foi adicionado ao sistema.`,
      });
      
      // Redirecionar para a página de cultos
      setLocation("/cultos");
    } catch (error) {
      console.error("Erro ao criar culto:", error);
      toast({
        title: "Erro ao criar culto",
        description: "Houve um problema ao criar o culto. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex h-screen bg-neutral-lightest overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Criar Novo Culto" />
        
        <main className="flex-1 overflow-y-auto p-4">
          <div className="container mx-auto">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h1 className="text-2xl font-bold mb-6 text-center">Cadastro de Culto</h1>
              <p className="text-neutral-dark mb-8 text-center">
                Preencha as informações abaixo para cadastrar um novo culto
              </p>
              
              <ServiceForm onSubmit={handleFormSubmit} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}