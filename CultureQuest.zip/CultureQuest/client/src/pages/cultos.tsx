import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Service } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { CalendarIcon, ArrowLeft, ArrowRight, Download, Plus, Edit, Trash } from "lucide-react";

export default function CultosPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toLocaleString('pt-BR', { month: 'long' }).toUpperCase());
  const [currentMonthIndex, setCurrentMonthIndex] = useState<number>(new Date().getMonth());
  
  const meses = [
    'JANEIRO', 'FEVEREIRO', 'MARÇO', 'ABRIL', 'MAIO', 'JUNHO', 
    'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO'
  ];
  
  const handlePreviousMonth = () => {
    const newIndex = currentMonthIndex > 0 ? currentMonthIndex - 1 : 11;
    setCurrentMonthIndex(newIndex);
    setSelectedMonth(meses[newIndex]);
  };
  
  const handleNextMonth = () => {
    const newIndex = currentMonthIndex < 11 ? currentMonthIndex + 1 : 0;
    setCurrentMonthIndex(newIndex);
    setSelectedMonth(meses[newIndex]);
  };
  
  const handleMonthClick = (month: string, index: number) => {
    setSelectedMonth(month);
    setCurrentMonthIndex(index);
  };

  // Buscar os dados dos cultos
  const { data: services, isLoading } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });
  
  // Filtrar cultos pelo mês selecionado
  const filteredServices = services?.filter(service => {
    const serviceMonth = new Date(service.date).getMonth();
    return serviceMonth === currentMonthIndex;
  });
  
  // Agrupar cultos pela mesma data
  const groupedServices = filteredServices?.reduce((acc, service) => {
    const date = formatDate(service.date, 'dd/MM');
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(service);
    return acc;
  }, {} as Record<string, Service[]>) || {};
  
  // Função para determinar o estado do culto (realizado, próximo)
  const getServiceStatus = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const serviceDate = new Date(date);
    serviceDate.setHours(0, 0, 0, 0);
    
    if (serviceDate < today) {
      return "realizado";
    } else if (serviceDate.getTime() === today.getTime()) {
      return "proximo";
    } else {
      return "futuro";
    }
  };
  
  // Determinar o próximo culto
  const getNextServices = () => {
    if (!services) return [];
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return services
      .filter(service => {
        const serviceDate = new Date(service.date);
        serviceDate.setHours(0, 0, 0, 0);
        return serviceDate >= today;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 3);
  };
  
  const nextServices = getNextServices();
  
  // Exportar PDF dos cultos
  const handleExportPDF = () => {
    toast({
      title: "Exportar PDF",
      description: "Função de exportação para PDF será implementada em breve!",
    });
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64 bg-neutral-light">
        <Header title="Cultos" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex justify-between items-center mb-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
              <h2 className="text-xl font-bold">ESCALA MÍDIA:</h2>
              
              {user && user.role === "leader" && (
                <Link href="/criar-culto">
                  <Button variant="outline" className="flex items-center text-sm bg-primary hover:bg-primary/80 text-white border-transparent">
                    <Plus className="h-4 w-4 mr-1" />
                    Novo Culto
                  </Button>
                </Link>
              )}
            </div>
            
            <div className="flex items-center border border-primary rounded-full px-2 py-1 bg-white">
              <button 
                className="hover:bg-neutral-light rounded-full p-1"
                onClick={handlePreviousMonth}
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              
              <span className="px-2 font-medium">MÊS: {selectedMonth}</span>
              
              <button 
                className="hover:bg-neutral-light rounded-full p-1"
                onClick={handleNextMonth}
              >
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
          
          {/* Meses navegação */}
          <div className="flex justify-end mb-6">
            <div className="bg-white rounded-lg p-1">
              {meses.map((mes, index) => (
                <button
                  key={mes}
                  onClick={() => handleMonthClick(mes, index)}
                  className={`rounded-full h-6 w-6 mr-1 flex items-center justify-center text-xs ${
                    selectedMonth === mes ? 'bg-primary text-white' : 'bg-neutral-light text-gray-600'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </div>
          
          {/* Grid de cartões de culto */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {nextServices.map((service, index) => {
              const serviceStatus = getServiceStatus(new Date(service.date));
              const statusColors = {
                realizado: "bg-green-200 border-green-400",
                proximo: "bg-blue-200 border-blue-400",
                futuro: "bg-yellow-100 border-yellow-300",
              };
              
              const statusTitles = {
                realizado: "CULTO REALIZADO",
                proximo: "PRÓXIMO CULTO",
                futuro: "PRÓXIMO CULTO",
              };
              
              return (
                <div 
                  key={service.id} 
                  className={`${statusColors[serviceStatus as keyof typeof statusColors]} rounded-lg p-6 border-2`}
                >
                  <h3 className="text-center font-bold mb-3">{statusTitles[serviceStatus as keyof typeof statusTitles]}</h3>
                  <h4 className="text-center text-2xl font-bold mb-3">
                    {service.dayOfWeek.toUpperCase()}
                  </h4>
                  <p className="text-center font-bold text-xl mb-6">
                    {formatDate(service.date, 'dd/MM')}-{service.time}
                  </p>
                  
                  <div className="border-t border-b py-4">
                    <h5 className="text-center mb-2">ESCALA:</h5>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-right font-semibold">PROJEÇÃO:</div>
                      <div>TAIANE</div>
                      
                      <div className="text-right font-semibold">ILUMINAÇÃO:</div>
                      <div>TAIANE</div>
                      
                      <div className="text-right font-semibold">LIVE:</div>
                      <div>GIOVANA</div>
                      
                      <div className="text-right font-semibold">SOM:</div>
                      <div>PEDRO</div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mt-4">
                    {serviceStatus === "realizado" ? (
                      <div className="flex justify-center w-full">
                        <div className="rounded-full w-8 h-8 bg-white flex items-center justify-center border border-green-500">
                          <svg viewBox="0 0 24 24" width="16" height="16" stroke="green" strokeWidth="3" fill="none">
                            <polyline points="20 6 9 17 4 12"></polyline>
                          </svg>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="w-8"></div> {/* Espaçador vazio */}
                        {user && user.role === "leader" && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="ml-auto"
                            onClick={() => setLocation(`/editar-culto/${service.id}`)}
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Editar
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Botão de gerar PDF */}
          <div className="flex justify-center mb-6">
            <Button 
              variant="default" 
              className="bg-primary text-white px-6 py-2 rounded-lg flex items-center"
              onClick={handleExportPDF}
            >
              <Download className="h-4 w-4 mr-2" />
              GERAR PDF DOS CULTOS DO MÊS
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
}