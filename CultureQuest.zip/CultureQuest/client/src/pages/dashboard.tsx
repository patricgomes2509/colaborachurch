import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { DashboardData } from "@/lib/types";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import DashboardOverview from "@/components/dashboard/DashboardOverview";
import MinistrySchedule from "@/components/ministry/MinistrySchedule";
import TaskBoard from "@/components/task/TaskBoard";

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard'],
  });

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64">
        <Header title="Dashboard" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <p>Carregando...</p>
            </div>
          ) : (
            <>
              <h1 className="text-2xl font-bold font-montserrat mb-6">Bem-vindo ao ColaboraChurch</h1>
              
              {dashboardData && (
                <>
                  <DashboardOverview data={dashboardData} />
                  
                  {user?.ministryId && (
                    <>
                      <MinistrySchedule ministryId={user.ministryId} />
                      <TaskBoard ministryId={user.ministryId} />
                    </>
                  )}
                </>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
