import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Service } from "@shared/schema";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { ServiceForm } from "@/components/service/ServiceForm";
import { Skeleton } from "@/components/ui/skeleton";

export default function EditarCultoPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Verificar se o ID é válido
  if (isNaN(id)) {
    toast({
      title: "Erro",
      description: "ID do culto inválido",
      variant: "destructive"
    });
    setLocation("/cultos");
    return null;
  }

  // Verificar se o usuário tem permissão para editar cultos
  // Apenas líderes podem editar cultos
  if (user && user.role !== "leader") {
    toast({
      title: "Acesso negado",
      description: "Apenas líderes podem editar cultos",
      variant: "destructive"
    });
    setLocation("/cultos");
    return null;
  }

  // Buscar dados do culto
  const { data: service, isLoading, error } = useQuery<Service>({
    queryKey: [`/api/services/${id}`],
  });

  // Se ocorrer um erro ao carregar os dados
  if (error) {
    toast({
      title: "Erro ao carregar dados",
      description: "Não foi possível carregar os dados do culto",
      variant: "destructive"
    });
  }

  const handleFormSubmit = async (data: any) => {
    try {
      setIsSubmitting(true);
      
      // Enviar dados atualizados para a API
      const response = await apiRequest("PUT", `/api/services/${id}`, data);
      const updatedService = await response.json();
      
      // Invalidar cache para refletir as alterações
      queryClient.invalidateQueries({ queryKey: [`/api/services/${id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      queryClient.invalidateQueries({ queryKey: ['/api/services/upcoming'] });
      
      toast({
        title: "Culto atualizado com sucesso",
        description: `As informações do culto ${updatedService.name} foram atualizadas.`,
      });
      
      // Redirecionar para a página de cultos
      setLocation("/cultos");
    } catch (error) {
      console.error("Erro ao atualizar culto:", error);
      toast({
        title: "Erro ao atualizar culto",
        description: "Houve um problema ao atualizar o culto. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex h-screen bg-neutral-lightest overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Editar Culto" />
        
        <main className="flex-1 overflow-y-auto p-4">
          <div className="container mx-auto">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h1 className="text-2xl font-bold mb-6 text-center">Editar Culto</h1>
              
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <div className="grid grid-cols-2 gap-4">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-1/4 ml-auto" />
                </div>
              ) : service ? (
                <ServiceForm 
                  defaultValues={{
                    name: service.name,
                    date: new Date(service.date),
                    time: service.time,
                    status: service.status
                  }} 
                  onSubmit={handleFormSubmit}
                  isEditMode={true}
                />
              ) : (
                <p className="text-center text-red-500">Culto não encontrado</p>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}