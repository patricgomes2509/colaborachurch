import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Schedule, Service, Ministry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { CalendarIcon, Edit, Plus, ArrowLeft, ArrowRight } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function EscalasPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedMinistry, setSelectedMinistry] = useState<number | undefined>(user?.ministryId || undefined);
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toLocaleString('pt-BR', { month: 'long' }).toUpperCase());
  const [currentMonthIndex, setCurrentMonthIndex] = useState<number>(new Date().getMonth());
  
  const meses = [
    'JANEIRO', 'FEVEREIRO', 'MARÇO', 'ABRIL', 'MAIO', 'JUNHO', 
    'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO'
  ];
  
  const handlePreviousMonth = () => {
    const newIndex = currentMonthIndex > 0 ? currentMonthIndex - 1 : 11;
    setCurrentMonthIndex(newIndex);
    setSelectedMonth(meses[newIndex]);
  };
  
  const handleNextMonth = () => {
    const newIndex = currentMonthIndex < 11 ? currentMonthIndex + 1 : 0;
    setCurrentMonthIndex(newIndex);
    setSelectedMonth(meses[newIndex]);
  };

  // Buscar ministérios
  const { data: ministries } = useQuery<Ministry[]>({
    queryKey: ['/api/ministries'],
  });

  // Buscar escalas do ministério selecionado
  const { data: schedules, isLoading: schedulesLoading } = useQuery<Schedule[]>({
    queryKey: ['/api/ministries', selectedMinistry, 'schedules'],
    enabled: !!selectedMinistry,
  });

  // Buscar serviços/cultos
  const { data: services } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });
  
  // Filtrar escalas pelo mês selecionado
  const filteredSchedules = schedules?.filter(schedule => {
    const service = services?.find(s => s.id === schedule.serviceId);
    if (!service) return false;
    
    const serviceMonth = new Date(service.date).getMonth();
    return serviceMonth === currentMonthIndex;
  });
  
  // Verificar se é líder do ministério
  const isLeader = user?.role === 'leader' && user?.ministryId === selectedMinistry;
  
  // Função para adicionar nova escala
  const handleAddSchedule = () => {
    toast({
      title: "Nova escala",
      description: "Função para adicionar nova escala será implementada em breve!",
    });
  };
  
  // Função para editar escala
  const handleEditSchedule = (scheduleId: number) => {
    toast({
      title: "Editar escala",
      description: `Editando escala ID: ${scheduleId}`,
    });
  };
  
  // Função para determinar o status da escala baseado na data do serviço
  const getScheduleStatus = (serviceId: number) => {
    const service = services?.find(s => s.id === serviceId);
    if (!service) return "";
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const serviceDate = new Date(service.date);
    serviceDate.setHours(0, 0, 0, 0);
    
    if (serviceDate < today) {
      return "realizado";
    } else {
      return "pendente";
    }
  };

  // Função para buscar o nome do serviço
  const getServiceInfo = (serviceId: number) => {
    const service = services?.find(s => s.id === serviceId);
    if (!service) return { name: "Culto não encontrado", date: new Date(), formatted: "" };
    
    return {
      name: service.name,
      date: new Date(service.date),
      formatted: `${formatDate(service.date, 'dd/MM/yyyy')} - ${service.time}`
    };
  };

  // Função para obter o nome do ministério
  const getMinistryName = (ministryId: number) => {
    const ministry = ministries?.find(m => m.id === ministryId);
    return ministry?.name || "Ministério não encontrado";
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64 bg-neutral-light">
        <Header title="Escalas" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <div className="w-2 h-8 bg-primary rounded-full mr-3"></div>
              <h1 className="text-2xl font-bold">ESCALAS</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Seletor de Ministério */}
              <div className="relative">
                <select 
                  className="appearance-none bg-white border border-neutral-medium rounded-md px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-primary"
                  value={selectedMinistry}
                  onChange={(e) => setSelectedMinistry(Number(e.target.value))}
                >
                  <option value="">Selecione o ministério</option>
                  {ministries?.map(ministry => (
                    <option key={ministry.id} value={ministry.id}>
                      {ministry.name}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
              
              {/* Navegação de mês */}
              <div className="flex items-center border border-primary rounded-full px-2 py-1 bg-white">
                <button 
                  className="hover:bg-neutral-light rounded-full p-1"
                  onClick={handlePreviousMonth}
                >
                  <ArrowLeft className="h-4 w-4" />
                </button>
                
                <span className="px-2 font-medium">MÊS: {selectedMonth}</span>
                
                <button 
                  className="hover:bg-neutral-light rounded-full p-1"
                  onClick={handleNextMonth}
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              
              {/* Botão de adicionar nova escala (apenas para líderes) */}
              {isLeader && (
                <Button 
                  onClick={handleAddSchedule}
                  className="bg-primary text-white hover:bg-primary/90"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Nova Escala
                </Button>
              )}
            </div>
          </div>
          
          {/* Tabela de escalas */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            {schedulesLoading ? (
              <div className="flex justify-center items-center h-32">
                <p>Carregando escalas...</p>
              </div>
            ) : filteredSchedules && filteredSchedules.length > 0 ? (
              <Table>
                <TableHeader className="bg-primary/10">
                  <TableRow>
                    <TableHead className="py-3 text-neutral-dark font-semibold">Data</TableHead>
                    <TableHead className="py-3 text-neutral-dark font-semibold">Culto</TableHead>
                    <TableHead className="py-3 text-neutral-dark font-semibold">Ministério</TableHead>
                    <TableHead className="py-3 text-neutral-dark font-semibold">Escalados</TableHead>
                    <TableHead className="py-3 text-neutral-dark font-semibold">Status</TableHead>
                    {isLeader && (
                      <TableHead className="py-3 text-neutral-dark font-semibold">Ações</TableHead>
                    )}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSchedules.map((schedule) => {
                    const serviceInfo = getServiceInfo(schedule.serviceId);
                    const scheduleStatus = getScheduleStatus(schedule.serviceId);
                    
                    return (
                      <TableRow key={schedule.id} className={
                        scheduleStatus === 'realizado' 
                          ? 'bg-status-completed/20' 
                          : 'hover:bg-neutral-light'
                      }>
                        <TableCell className="font-medium">
                          {serviceInfo.formatted}
                        </TableCell>
                        <TableCell>{serviceInfo.name}</TableCell>
                        <TableCell>{getMinistryName(schedule.ministryId)}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {schedule.members?.map((member, idx) => (
                              <span key={idx} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                                {member.name} ({member.role})
                              </span>
                            )) || "Nenhum membro escalado"}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                            ${scheduleStatus === 'realizado' 
                              ? 'bg-status-completed/20 text-status-completed' 
                              : 'bg-status-pending/20 text-status-pending'
                            }`
                          }>
                            {scheduleStatus === 'realizado' ? 'Realizado' : 'Pendente'}
                          </span>
                        </TableCell>
                        {isLeader && (
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditSchedule(schedule.id)}
                              className="hover:bg-primary/10"
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Editar</span>
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <p className="text-neutral-dark mb-4">Nenhuma escala encontrada para o mês {selectedMonth}.</p>
                {isLeader && (
                  <Button 
                    onClick={handleAddSchedule}
                    className="bg-primary text-white hover:bg-primary/90"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Adicionar Nova Escala
                  </Button>
                )}
              </div>
            )}
          </div>
          
          <div className="mt-6 p-4 bg-white rounded-lg shadow-sm">
            <h2 className="font-semibold mb-2">Sobre as Escalas</h2>
            <p className="text-sm text-neutral-dark mb-2">
              • As escalas permitem organizar os voluntários para cada culto e ministério.
            </p>
            <p className="text-sm text-neutral-dark mb-2">
              • Cultos passados são marcados com cor verde.
            </p>
            <p className="text-sm text-neutral-dark">
              • Se precisar fazer uma contestação de escala, entre em contato com o líder do ministério.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}