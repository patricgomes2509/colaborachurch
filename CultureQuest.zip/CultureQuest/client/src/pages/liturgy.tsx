import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function LiturgyPage() {
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64">
        <Header title="Liturgia dos Cultos" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex items-center mb-6">
            <div className="w-2 h-8 bg-accent rounded-full mr-3"></div>
            <h1 className="text-2xl font-bold font-montserrat">Liturgia dos Cultos</h1>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Liturgia dos Cultos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-center py-10 text-neutral-dark">
                A funcionalidade de montagem colaborativa de liturgia estará disponível em breve.
              </p>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
