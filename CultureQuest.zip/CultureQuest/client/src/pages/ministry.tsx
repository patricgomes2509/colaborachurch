import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Ministry } from "@shared/schema";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import MinistrySchedule from "@/components/ministry/MinistrySchedule";
import { ServiceCards } from "@/components/service/ServiceCards";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, UsersIcon, CheckSquareIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MinistryPageProps {
  slug: string;
}

export default function MinistryPage({ slug }: MinistryPageProps) {
  const { toast } = useToast();
  const [ministryId, setMinistryId] = useState<number | null>(null);

  // Fetch ministry details by slug
  const { data: ministry, isLoading: isLoadingMinistry, error } = useQuery<Ministry>({
    queryKey: [`/api/ministries/slug/${slug}`],
    enabled: !!slug,
  });

  useEffect(() => {
    if (ministry) {
      setMinistryId(ministry.id);
    }
  }, [ministry]);

  useEffect(() => {
    if (error) {
      toast({
        title: "Erro ao carregar ministério",
        description: "Verifique se você tem permissão para acessar este ministério.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64">
        <Header title={ministry?.name || "Ministério"} />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          {isLoadingMinistry ? (
            <div className="flex items-center justify-center h-64">
              <p>Carregando...</p>
            </div>
          ) : ministry ? (
            <>
              <div className="flex items-center mb-6">
                <div className={`w-2 h-8 bg-primary rounded-full mr-3`}></div>
                <h1 className="text-2xl font-bold font-montserrat">{ministry.name}</h1>
              </div>
              
              {ministryId && (
                <Tabs defaultValue="services" className="w-full">
                  <TabsList className="mb-6">
                    <TabsTrigger value="services">
                      <CalendarIcon className="h-4 w-4 mr-2" />
                      Cultos
                    </TabsTrigger>
                    <TabsTrigger value="schedule">
                      <UsersIcon className="h-4 w-4 mr-2" />
                      Escalas
                    </TabsTrigger>
                    <TabsTrigger value="tasks">
                      <CheckSquareIcon className="h-4 w-4 mr-2" />
                      Tarefas
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="services" className="mt-0">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h2 className="text-lg font-semibold mb-4">Cultos e Escalas de Voluntários</h2>
                      <p className="text-gray-500 text-sm mb-6">
                        Visualize os próximos cultos, crie e gerencie as escalas de voluntários.
                        Os cultos são marcados por cores: <span className="text-green-600 font-medium">verde</span> para cultos já realizados, 
                        <span className="text-blue-600 font-medium"> azul</span> para o próximo culto, e 
                        <span className="text-yellow-600 font-medium"> amarelo</span> para cultos futuros.
                      </p>
                      
                      <ServiceCards ministryId={ministryId} />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="schedule" className="mt-0">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h2 className="text-lg font-semibold mb-4">Escalas do Ministério</h2>
                      <MinistrySchedule ministryId={ministryId} />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="tasks" className="mt-0">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <h2 className="text-lg font-semibold mb-4">Tarefas do Ministério</h2>
                      <p className="text-gray-500">Em breve você poderá gerenciar tarefas específicas do ministério aqui.</p>
                    </div>
                  </TabsContent>
                </Tabs>
              )}
            </>
          ) : (
            <div className="text-center p-10">
              <h2 className="text-xl font-semibold">Ministério não encontrado</h2>
              <p className="mt-2">O ministério que você está procurando não existe ou você não tem permissão para acessá-lo.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
