import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { UserForm } from "@/components/user/UserForm";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";

export default function RegisterUserPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  
  // Verificar se o usuário tem permissão para criar outros usuários
  // Apenas líderes podem criar usuários
  if (user && user.role !== "leader") {
    toast({
      title: "Acesso negado",
      description: "Apenas líderes podem cadastrar novos usuários",
      variant: "destructive"
    });
    setLocation("/");
    return null;
  }
  
  const handleFormSubmit = async (data: any) => {
    try {
      // Remover campos não necessários para a API
      const { ministryIds, ...userData } = data;
      
      // Criar o usuário
      const response = await apiRequest("POST", '/api/users', userData);
      
      const newUser = await response.json();
      
      // Se há ministérios adicionais, adicionar cada um
      if (ministryIds && ministryIds.length > 0) {
        // Excluir o ministério principal se estiver na lista
        const additionalMinistries = ministryIds.filter(
          (id: number) => id !== userData.ministryId
        );
        
        // Adicionar cada ministério adicional
        for (const ministryId of additionalMinistries) {
          await apiRequest("POST", '/api/user-ministries', {
            userId: newUser.id,
            ministryId
          });
        }
      }
      
      // Invalidar o cache de usuários após criar um novo
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      
      toast({
        title: "Usuário criado com sucesso",
        description: `${newUser.fullName} foi adicionado ao sistema`,
      });
      
      // Navegar para a página de dashboard ou listagem de usuários
      setLocation("/");
    } catch (error) {
      console.error("Erro ao criar usuário:", error);
      toast({
        title: "Erro ao criar usuário",
        description: "Houve um problema ao criar o usuário. Tente novamente.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="flex h-screen bg-neutral-lightest overflow-hidden">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Cadastrar Novo Usuário" />
        
        <main className="flex-1 overflow-y-auto p-4">
          <div className="container mx-auto">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h1 className="text-2xl font-bold mb-6 text-center">Cadastro de Usuário</h1>
              <p className="text-neutral-dark mb-8 text-center">
                Preencha as informações abaixo para cadastrar um novo usuário no sistema
              </p>
              
              <UserForm onSubmit={handleFormSubmit} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}