import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { InitialsAvatar } from "@/components/ui/initials-avatar";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardHeader,
  CardContent,
  CardDescription,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { Upload, SaveIcon, Camera, Bell, User, Settings, MessageSquare } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const profileSchema = z.object({
  fullName: z.string().min(2, "Nome completo deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  phone: z.string().optional(),
  bio: z.string().optional()
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function SettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("perfil");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [chatNotifications, setChatNotifications] = useState(true);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      bio: user?.bio || ""
    }
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAvatarFile(file);
      
      const reader = new FileReader();
      reader.onload = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      
      toast({
        title: "Avatar selecionado",
        description: "Clique em Salvar para aplicar as alterações."
      });
    }
  };

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      // Aqui enviaria os dados para a API
      return await new Promise(resolve => setTimeout(() => resolve(data), 1000));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram atualizadas com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar seu perfil. Tente novamente.",
        variant: "destructive"
      });
    }
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: async (file: File) => {
      // Aqui enviaria o arquivo para a API
      return await new Promise(resolve => setTimeout(() => resolve(URL.createObjectURL(file)), 1000));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      toast({
        title: "Avatar atualizado",
        description: "Sua foto de perfil foi atualizada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar sua foto. Tente novamente.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
    
    if (avatarFile) {
      uploadAvatarMutation.mutate(avatarFile);
    }
  };

  const saveNotificationSettings = () => {
    toast({
      title: "Configurações salvas",
      description: "Suas preferências de notificação foram atualizadas com sucesso!",
    });
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64 bg-neutral-light">
        <Header title="Configurações" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex items-center mb-6">
            <div className="w-2 h-8 bg-primary rounded-full mr-3"></div>
            <h1 className="text-2xl font-bold">CONFIGURAÇÕES</h1>
          </div>
          
          <Tabs defaultValue="perfil" className="space-y-4" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="perfil" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>Perfil</span>
              </TabsTrigger>
              <TabsTrigger value="notificacoes" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <span>Notificações</span>
              </TabsTrigger>
              <TabsTrigger value="chat" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span>Chat</span>
              </TabsTrigger>
            </TabsList>
            
            {/* Aba de Perfil */}
            <TabsContent value="perfil" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Meu Perfil</CardTitle>
                  <CardDescription>
                    Atualize suas informações pessoais e imagem de perfil.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-8">
                    {/* Área de upload de avatar */}
                    <div className="flex flex-col items-center space-y-4">
                      <div className="relative w-32 h-32">
                        {avatarPreview ? (
                          <img 
                            src={avatarPreview} 
                            alt="Avatar Preview" 
                            className="w-32 h-32 rounded-full object-cover"
                          />
                        ) : (
                          <InitialsAvatar 
                            name={user?.fullName || ""} 
                            size="lg"
                            className="w-32 h-32 !text-xl"
                          />
                        )}
                        <label 
                          htmlFor="avatar-upload" 
                          className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full cursor-pointer hover:bg-primary/90"
                        >
                          <Camera className="h-5 w-5" />
                        </label>
                        <input 
                          id="avatar-upload" 
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleAvatarChange}
                        />
                      </div>
                      <div className="text-sm text-center">
                        <p className="font-medium">Foto de Perfil</p>
                        <p className="text-neutral-dark">JPG, PNG ou GIF</p>
                      </div>
                    </div>
                    
                    {/* Formulário de informações */}
                    <div className="flex-1">
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Nome Completo</FormLabel>
                                <FormControl>
                                  <Input placeholder="Seu nome completo" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                  <Input type="email" placeholder="seu.email@exemplo.com" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Telefone</FormLabel>
                                <FormControl>
                                  <Input placeholder="(00) 00000-0000" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="bio"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Sobre Mim</FormLabel>
                                <FormControl>
                                  <textarea 
                                    className="w-full min-h-[100px] p-3 rounded-md border border-input bg-background"
                                    placeholder="Fale um pouco sobre você..."
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <Button 
                            type="submit" 
                            className="w-full mt-4"
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>Salvando...</>
                            ) : (
                              <>
                                <SaveIcon className="h-4 w-4 mr-2" />
                                Salvar Alterações
                              </>
                            )}
                          </Button>
                        </form>
                      </Form>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Aba de Notificações */}
            <TabsContent value="notificacoes" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Preferências de Notificação</CardTitle>
                  <CardDescription>
                    Configure como deseja receber suas notificações.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="notifications" className="font-medium">Notificações</Label>
                      <p className="text-sm text-neutral-dark">Habilitar ou desabilitar todas as notificações</p>
                    </div>
                    <Switch 
                      id="notifications" 
                      checked={notificationsEnabled}
                      onCheckedChange={setNotificationsEnabled}
                    />
                  </div>
                  
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-2">Tipos de Notificação</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="email-notifications" className="font-medium">Email</Label>
                          <p className="text-sm text-neutral-dark">Receber notificações por email</p>
                        </div>
                        <Switch 
                          id="email-notifications" 
                          checked={emailNotifications}
                          onCheckedChange={setEmailNotifications}
                          disabled={!notificationsEnabled}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="chat-notifications" className="font-medium">Chat</Label>
                          <p className="text-sm text-neutral-dark">Notificações de novas mensagens</p>
                        </div>
                        <Switch 
                          id="chat-notifications" 
                          checked={chatNotifications}
                          onCheckedChange={setChatNotifications}
                          disabled={!notificationsEnabled}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={saveNotificationSettings} className="ml-auto">
                    <SaveIcon className="h-4 w-4 mr-2" />
                    Salvar Preferências
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Aba de Chat */}
            <TabsContent value="chat" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Chat</CardTitle>
                  <CardDescription>
                    Configure suas preferências de conversação com outros membros.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="chat-status" className="font-medium">Status do Chat</Label>
                      <p className="text-sm text-neutral-dark">Aparecer online para outros membros</p>
                    </div>
                    <Switch 
                      id="chat-status" 
                      defaultChecked={true}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="read-receipts" className="font-medium">Confirmação de Leitura</Label>
                      <p className="text-sm text-neutral-dark">Permitir que outros saibam quando você leu a mensagem</p>
                    </div>
                    <Switch 
                      id="read-receipts" 
                      defaultChecked={true}
                    />
                  </div>
                  
                  <div className="border-t pt-4 mt-4">
                    <h3 className="font-medium mb-2">Privacidade</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="direct-messages" className="font-medium">Mensagens Diretas</Label>
                          <p className="text-sm text-neutral-dark">Quem pode enviar mensagens para você?</p>
                        </div>
                        <select
                          id="direct-messages"
                          className="p-2 rounded-md border border-neutral-medium"
                          defaultValue="all"
                        >
                          <option value="all">Todos os membros</option>
                          <option value="ministry">Apenas meu ministério</option>
                          <option value="leaders">Apenas líderes</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="ml-auto">
                    <SaveIcon className="h-4 w-4 mr-2" />
                    Salvar Configurações
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}