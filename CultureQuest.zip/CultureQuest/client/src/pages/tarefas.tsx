import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Task, Ministry, User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { 
  Plus, Check, Clock, AlertTriangle, Calendar, 
  ChevronDown, Filter, MoreVertical, Edit, Trash,
  CheckCircle
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { InitialsAvatar } from "@/components/ui/initials-avatar";

export default function TarefasPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedMinistry, setSelectedMinistry] = useState<number | undefined>(user?.ministryId || undefined);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  
  // Buscar ministérios
  const { data: ministries } = useQuery<Ministry[]>({
    queryKey: ['/api/ministries'],
  });

  // Buscar tarefas do ministério selecionado
  const { data: tasksData, isLoading: tasksLoading } = useQuery<{tasks: Task[], users: User[]}>({
    queryKey: ['/api/ministries', selectedMinistry, 'tasks'],
    enabled: !!selectedMinistry,
  });
  
  // Filtrar tarefas pelo status
  const filteredTasks = tasksData?.tasks?.filter(task => {
    if (statusFilter === "all") return true;
    return task.status === statusFilter;
  }) || [];
  
  // Verificar se é líder do ministério
  const isLeader = user?.role === 'leader' && user?.ministryId === selectedMinistry;
  
  // Função para adicionar nova tarefa
  const handleAddTask = () => {
    toast({
      title: "Nova tarefa",
      description: "Função para adicionar nova tarefa será implementada em breve!",
    });
  };
  
  // Função para editar tarefa
  const handleEditTask = (taskId: number) => {
    toast({
      title: "Editar tarefa",
      description: `Editando tarefa ID: ${taskId}`,
    });
  };
  
  // Função para excluir tarefa
  const handleDeleteTask = (taskId: number) => {
    toast({
      title: "Excluir tarefa",
      description: `Excluindo tarefa ID: ${taskId}`,
    });
  };
  
  // Função para marcar tarefa como completa
  const handleCompleteTask = (taskId: number) => {
    toast({
      title: "Concluir tarefa",
      description: `Marcando tarefa ID: ${taskId} como concluída`,
    });
  };
  
  // Enviar tarefa para o webhook
  const sendTaskToWebhook = async (task: Task, operation: string) => {
    try {
      const webhookUrl = "https://patricgomes.app.n8n.cloud/webhook-test/0b93fb2d-fead-4987-8a74-10f09e732ab2";
      
      const ministry = ministries?.find(m => m.id === task.ministryId);
      
      const payload = {
        tipo_operacao: operation,
        nome_ministerio: ministry?.name || "Desconhecido",
        dados: {
          id: task.id,
          titulo: task.title,
          descricao: task.description,
          status: task.status,
          prioridade: task.priority,
          data_vencimento: task.dueDate ? formatDate(task.dueDate) : null,
          responsaveis: task.assignees || []
        }
      };
      
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      
      if (response.ok) {
        console.log("Dados enviados com sucesso para o webhook");
      } else {
        console.error("Erro ao enviar dados para o webhook");
      }
    } catch (error) {
      console.error("Erro ao enviar dados para o webhook:", error);
    }
  };
  
  // Função para obter o nome do ministério
  const getMinistryName = (ministryId: number) => {
    const ministry = ministries?.find(m => m.id === ministryId);
    return ministry?.name || "Ministério não encontrado";
  };
  
  // Função para obter informações dos usuários atribuídos à tarefa
  const getAssigneeInfo = (assignees: number[] | null = []) => {
    if (!tasksData?.users || !assignees) return [];
    
    return assignees.map(id => {
      const user = tasksData.users.find(u => u.id === id);
      return user ? { id, name: user.fullName } : { id, name: `Usuário #${id}` };
    });
  };
  
  // Renderizar o indicador de status da tarefa
  const renderStatusIndicator = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <div className="flex items-center text-status-completed">
            <Check className="h-4 w-4 mr-1" />
            <span>Concluída</span>
          </div>
        );
      case "overdue":
        return (
          <div className="flex items-center text-status-overdue">
            <AlertTriangle className="h-4 w-4 mr-1" />
            <span>Atrasada</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center text-status-pending">
            <Clock className="h-4 w-4 mr-1" />
            <span>Pendente</span>
          </div>
        );
    }
  };
  
  // Cores para prioridade
  const priorityColors = {
    high: "text-status-overdue",
    medium: "text-status-pending",
    low: "text-green-600",
  };
  
  // Rótulos para prioridade
  const priorityLabels = {
    high: "Alta",
    medium: "Média",
    low: "Baixa",
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64 bg-neutral-light">
        <Header title="Tarefas Colaborativas" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <div className="w-2 h-8 bg-status-pending rounded-full mr-3"></div>
              <h1 className="text-2xl font-bold">TAREFAS COLABORATIVAS</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Seletor de Ministério */}
              <div className="relative">
                <select 
                  className="appearance-none bg-white border border-neutral-medium rounded-md px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-primary"
                  value={selectedMinistry}
                  onChange={(e) => setSelectedMinistry(Number(e.target.value))}
                >
                  <option value="">Selecione o ministério</option>
                  {ministries?.map(ministry => (
                    <option key={ministry.id} value={ministry.id}>
                      {ministry.name}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <ChevronDown className="h-4 w-4 text-gray-400" />
                </div>
              </div>
              
              {/* Filtro de Status */}
              <div className="relative">
                <select
                  className="appearance-none bg-white border border-neutral-medium rounded-md px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-primary"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">Todos os status</option>
                  <option value="pending">Pendentes</option>
                  <option value="overdue">Atrasadas</option>
                  <option value="completed">Concluídas</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <Filter className="h-4 w-4 text-gray-400" />
                </div>
              </div>
              
              {/* Botão de adicionar nova tarefa */}
              <Button 
                onClick={handleAddTask}
                className="bg-status-pending text-white hover:bg-status-pending/90"
              >
                <Plus className="h-4 w-4 mr-1" />
                Nova Tarefa
              </Button>
            </div>
          </div>
          
          {/* Grid de Tarefas */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            {tasksLoading ? (
              <div className="flex justify-center items-center h-32 col-span-full">
                <p>Carregando tarefas...</p>
              </div>
            ) : filteredTasks && filteredTasks.length > 0 ? (
              filteredTasks.map((task) => {
                const assignees = getAssigneeInfo(task.assignees);
                const isPastDue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== "completed";
                const status = task.status === "completed" ? "completed" : isPastDue ? "overdue" : "pending";
                
                // Determinar cor do card baseado no status
                const cardBorderColor = 
                  status === "completed" 
                    ? "border-status-completed" 
                    : status === "overdue" 
                      ? "border-status-overdue" 
                      : "border-status-pending";
                
                return (
                  <Card key={task.id} className={`border-2 ${cardBorderColor}`}>
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{task.title}</CardTitle>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                              <span className="sr-only">Opções</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleCompleteTask(task.id)}>
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Marcar como concluída
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditTask(task.id)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              onClick={() => handleDeleteTask(task.id)}
                              className="text-status-overdue"
                            >
                              <Trash className="h-4 w-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      
                      <div className="flex items-center justify-between mt-1">
                        <span className={`text-xs ${priorityColors[task.priority as keyof typeof priorityColors]}`}>
                          Prioridade: {priorityLabels[task.priority as keyof typeof priorityLabels]}
                        </span>
                        {renderStatusIndicator(status)}
                      </div>
                      
                      <CardDescription className="mt-2">
                        {task.description || "Sem descrição"}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="pb-3">
                      {task.dueDate && (
                        <div className="flex items-center text-sm text-neutral-dark mb-3">
                          <Calendar className="h-4 w-4 mr-2" />
                          <span>Prazo: {formatDate(task.dueDate)}</span>
                        </div>
                      )}
                      
                      {assignees.length > 0 && (
                        <div>
                          <div className="text-sm font-medium mb-1">Responsáveis:</div>
                          <div className="flex flex-wrap gap-2">
                            {assignees.map((assignee) => (
                              <div key={assignee.id} className="flex items-center">
                                <InitialsAvatar name={assignee.name} size="sm" />
                                <span className="ml-1 text-sm">{assignee.name}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                    
                    <CardFooter className="border-t pt-3 flex justify-between">
                      <div className="text-xs text-neutral-dark">
                        Ministério: {getMinistryName(task.ministryId)}
                      </div>
                      <div className="text-xs text-neutral-dark">
                        Criada: {formatDate(task.createdAt)}
                      </div>
                    </CardFooter>
                  </Card>
                );
              })
            ) : (
              <div className="flex flex-col items-center justify-center py-8 col-span-full">
                <p className="text-neutral-dark mb-4">Nenhuma tarefa encontrada.</p>
                <Button 
                  onClick={handleAddTask}
                  className="bg-status-pending text-white hover:bg-status-pending/90"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Adicionar Nova Tarefa
                </Button>
              </div>
            )}
          </div>
          
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h2 className="font-semibold mb-3">Sobre as Tarefas Colaborativas</h2>
            <p className="text-sm text-neutral-dark mb-2">
              • As tarefas colaborativas permitem a organização e distribuição de trabalho entre os membros dos ministérios.
            </p>
            <p className="text-sm text-neutral-dark mb-2">
              • <span className="text-status-pending font-medium">Amarelo</span>: tarefas pendentes
              | <span className="text-status-overdue font-medium">Vermelho</span>: tarefas atrasadas
              | <span className="text-status-completed font-medium">Verde</span>: tarefas concluídas
            </p>
            <p className="text-sm text-neutral-dark">
              • Voluntários podem sugerir tarefas que serão aprovadas pelos líderes do ministério.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}