import { useAuth } from "@/contexts/AuthContext";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";
import TaskBoard from "@/components/task/TaskBoard";
import { useToast } from "@/hooks/use-toast";

export default function TasksPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Ensure user has a ministry assigned
  if (!user?.ministryId) {
    toast({
      title: "Erro",
      description: "Você precisa estar associado a um ministério para acessar as tarefas.",
      variant: "destructive",
    });
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      
      <div className="flex-1 transition-all duration-200 md:ml-64">
        <Header title="Tarefas Colaborativas" />
        
        <main className="py-6 px-4 sm:px-6 md:px-8">
          <div className="flex items-center mb-6">
            <div className="w-2 h-8 bg-secondary rounded-full mr-3"></div>
            <h1 className="text-2xl font-bold font-montserrat">Tarefas Colaborativas</h1>
          </div>
          
          {user?.ministryId ? (
            <TaskBoard ministryId={user.ministryId} fullView={true} />
          ) : (
            <div className="text-center p-10">
              <h2 className="text-xl font-semibold">Nenhum ministério associado</h2>
              <p className="mt-2">Você precisa estar associado a um ministério para visualizar tarefas.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
