import { db } from './db';
import { eq, and, desc, gte, lt } from 'drizzle-orm';
import {
  users, ministries, services, schedules, 
  contestations, tasks, canteenMenus, accessRules, birthdayNotifications,
  userMinistries,
  User, Ministry, Service, Schedule, 
  Contestation, Task, CanteenMenu, AccessRule, BirthdayNotification,
  UserMinistry,
  InsertUser, InsertMinistry, InsertService, InsertSchedule, 
  InsertContestation, InsertTask, InsertCanteenMenu, InsertAccessRule, 
  InsertBirthdayNotification, InsertUserMinistry,
  RoleType, ServiceStatus, TaskStatus, Priority
} from '@shared/schema';
import { IStorage } from './storage';

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id));
    return results[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username));
    return results[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Garantir que o tipo de role seja RoleType válido
    const validUser = {
      ...insertUser,
      role: insertUser.role ? 
        (insertUser.role === 'leader' || insertUser.role === 'volunteer' ? 
          insertUser.role as RoleType : 'volunteer' as RoleType) 
        : 'volunteer' as RoleType
    };
    
    const result = await db.insert(users).values(validUser).returning();
    return result[0];
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    // Processar atualizações garantindo os tipos corretos
    const processedUpdates = {...updates};
    
    // Garantir que role é do tipo RoleType
    if (typeof updates.role === 'string') {
      processedUpdates.role = 
        (updates.role === 'leader' || updates.role === 'volunteer') ? 
          updates.role as RoleType : 
          'volunteer' as RoleType;
    }
    
    const result = await db.update(users)
      .set(processedUpdates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUsersByMinistry(ministryId: number): Promise<User[]> {
    const userIds = await db.select().from(userMinistries)
      .where(eq(userMinistries.ministryId, ministryId));
    
    if (userIds.length === 0) return [];
    
    const userList: User[] = [];
    for (const rel of userIds) {
      const user = await this.getUser(rel.userId);
      if (user) userList.push(user);
    }
    
    return userList;
  }

  async getUsersWithBirthdays(month: number): Promise<User[]> {
    // Extrai o mês da data de aniversário
    const usersWithBirthdays = await db.select().from(users)
      .where(users.birthDate.isNotNull());
    
    return usersWithBirthdays.filter(user => {
      if (!user.birthDate) return false;
      const birthMonth = new Date(user.birthDate).getMonth() + 1; // Os meses começam em 0
      return birthMonth === month;
    });
  }

  async getUsersWithUpcomingBirthdays(days: number): Promise<User[]> {
    const today = new Date();
    const endDate = new Date();
    endDate.setDate(today.getDate() + days);
    
    const usersWithBirthdays = await db.select().from(users)
      .where(users.birthDate.isNotNull());
    
    return usersWithBirthdays.filter(user => {
      if (!user.birthDate) return false;
      
      const birthDate = new Date(user.birthDate);
      const birthMonth = birthDate.getMonth();
      const birthDay = birthDate.getDate();
      
      // Verificar se o aniversário cai dentro dos próximos 'days' dias
      const thisYearBirthday = new Date(today.getFullYear(), birthMonth, birthDay);
      
      // Se o aniversário já passou este ano, verificar o próximo ano
      if (thisYearBirthday < today) {
        thisYearBirthday.setFullYear(today.getFullYear() + 1);
      }
      
      return thisYearBirthday <= endDate;
    });
  }

  // User-Ministry operations
  async addUserToMinistry(userMinistry: InsertUserMinistry): Promise<UserMinistry> {
    const result = await db.insert(userMinistries).values(userMinistry).returning();
    return result[0];
  }

  async removeUserFromMinistry(userId: number, ministryId: number): Promise<boolean> {
    const result = await db.delete(userMinistries)
      .where(
        and(
          eq(userMinistries.userId, userId),
          eq(userMinistries.ministryId, ministryId)
        )
      );
    return true;
  }

  async getUserMinistries(userId: number): Promise<Ministry[]> {
    const relations = await db.select().from(userMinistries)
      .where(eq(userMinistries.userId, userId));
    
    if (relations.length === 0) return [];
    
    const ministryList: Ministry[] = [];
    for (const rel of relations) {
      const ministry = await this.getMinistry(rel.ministryId);
      if (ministry) ministryList.push(ministry);
    }
    
    return ministryList;
  }

  async getMinistryUsers(ministryId: number): Promise<User[]> {
    return await this.getUsersByMinistry(ministryId);
  }

  // Birthday Notification operations
  async createBirthdayNotification(notification: InsertBirthdayNotification): Promise<BirthdayNotification> {
    const notificationWithDate = {
      ...notification,
      notifiedDate: new Date()
    };
    const result = await db.insert(birthdayNotifications).values(notificationWithDate).returning();
    return result[0];
  }

  async getBirthdayNotifications(viewed?: boolean): Promise<BirthdayNotification[]> {
    if (viewed !== undefined) {
      return await db.select().from(birthdayNotifications)
        .where(eq(birthdayNotifications.viewed, viewed));
    }
    return await db.select().from(birthdayNotifications);
  }

  async markBirthdayNotificationAsViewed(id: number): Promise<BirthdayNotification | undefined> {
    const result = await db.update(birthdayNotifications)
      .set({ viewed: true })
      .where(eq(birthdayNotifications.id, id))
      .returning();
    return result[0];
  }

  // Ministry operations
  async getMinistry(id: number): Promise<Ministry | undefined> {
    const results = await db.select().from(ministries).where(eq(ministries.id, id));
    return results[0];
  }

  async getMinistryBySlug(slug: string): Promise<Ministry | undefined> {
    const results = await db.select().from(ministries).where(eq(ministries.slug, slug));
    return results[0];
  }

  async createMinistry(ministry: InsertMinistry): Promise<Ministry> {
    const result = await db.insert(ministries).values(ministry).returning();
    return result[0];
  }

  async getMinistries(): Promise<Ministry[]> {
    return await db.select().from(ministries);
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    const results = await db.select().from(services).where(eq(services.id, id));
    return results[0];
  }

  async createService(service: InsertService): Promise<Service> {
    // Certifique-se de que o status seja um valor válido de ServiceStatus
    const validService = {
      ...service,
      status: service.status ? 
        (service.status as ServiceStatus) : 
        'pending' as ServiceStatus
    };
    const result = await db.insert(services).values(validService).returning();
    return result[0];
  }

  async updateService(id: number, updates: Partial<InsertService>): Promise<Service | undefined> {
    // Se tiver atualizações no status, garantir que é do tipo ServiceStatus
    const processedUpdates = {...updates};
    if (typeof updates.status === 'string') {
      processedUpdates.status = updates.status as ServiceStatus;
    }
    
    const result = await db.update(services)
      .set(processedUpdates)
      .where(eq(services.id, id))
      .returning();
    return result[0];
  }

  async getServices(): Promise<Service[]> {
    return await db.select().from(services);
  }

  async getUpcomingServices(limit: number = 5): Promise<Service[]> {
    const today = new Date();
    
    return await db.select()
      .from(services)
      .where(gte(services.date, today))
      .orderBy(services.date)
      .limit(limit);
  }

  // Schedule operations
  async getSchedule(id: number): Promise<Schedule | undefined> {
    const results = await db.select().from(schedules).where(eq(schedules.id, id));
    return results[0];
  }

  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    // Garantir que o status é do tipo ServiceStatus
    const validSchedule = {
      ...schedule,
      status: schedule.status ? (schedule.status as ServiceStatus) : 'pending' as ServiceStatus,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    const result = await db.insert(schedules).values(validSchedule).returning();
    return result[0];
  }

  async updateSchedule(id: number, updates: Partial<InsertSchedule>): Promise<Schedule | undefined> {
    // Processar atualizações garantindo que os tipos estão corretos
    const processedUpdates = {...updates};
    if (typeof updates.status === 'string') {
      processedUpdates.status = updates.status as ServiceStatus;
    }
    
    const result = await db.update(schedules)
      .set({
        ...processedUpdates,
        updatedAt: new Date()
      })
      .where(eq(schedules.id, id))
      .returning();
    return result[0];
  }

  async deleteSchedule(id: number): Promise<boolean> {
    await db.delete(schedules).where(eq(schedules.id, id));
    return true;
  }

  async getSchedulesByMinistry(ministryId: number): Promise<Schedule[]> {
    return await db.select()
      .from(schedules)
      .where(eq(schedules.ministryId, ministryId));
  }

  async getSchedulesByService(serviceId: number): Promise<Schedule[]> {
    return await db.select()
      .from(schedules)
      .where(eq(schedules.serviceId, serviceId));
  }

  // Contestation operations
  async getContestation(id: number): Promise<Contestation | undefined> {
    const results = await db.select().from(contestations).where(eq(contestations.id, id));
    return results[0];
  }

  async createContestation(contestation: InsertContestation): Promise<Contestation> {
    // Garantir que status seja definido corretamente
    const validContestation = {
      ...contestation,
      status: contestation.status || 'pending',
      createdAt: new Date()
    };
    
    const result = await db.insert(contestations).values(validContestation).returning();
    return result[0];
  }

  async updateContestation(id: number, status: string): Promise<Contestation | undefined> {
    const result = await db.update(contestations)
      .set({ status })
      .where(eq(contestations.id, id))
      .returning();
    return result[0];
  }

  async getContestationsBySchedule(scheduleId: number): Promise<Contestation[]> {
    return await db.select()
      .from(contestations)
      .where(eq(contestations.scheduleId, scheduleId));
  }

  async getContestationsByUser(userId: number): Promise<Contestation[]> {
    return await db.select()
      .from(contestations)
      .where(eq(contestations.userId, userId));
  }

  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    const results = await db.select().from(tasks).where(eq(tasks.id, id));
    return results[0];
  }

  async createTask(task: InsertTask): Promise<Task> {
    // Garantir que status e priority sejam do tipo correto
    const validTask = {
      ...task,
      status: task.status ? (task.status as TaskStatus) : 'pending' as TaskStatus,
      priority: task.priority ? (task.priority as Priority) : 'medium' as Priority,
      createdAt: new Date(),
      updatedAt: new Date(),
      completedAt: null
    };
    
    const result = await db.insert(tasks).values(validTask).returning();
    return result[0];
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined> {
    // Processar atualizações garantindo os tipos corretos
    const processedUpdates: any = {
      ...updates,
      updatedAt: new Date()
    };
    
    // Garantir que status e priority são do tipo correto
    if (typeof updates.status === 'string') {
      processedUpdates.status = updates.status as TaskStatus;
    }
    
    if (typeof updates.priority === 'string') {
      processedUpdates.priority = updates.priority as Priority;
    }
    
    // Se a tarefa está sendo marcada como concluída, adicione a data de conclusão
    if (updates.status === 'completed' && !updates.completedAt) {
      processedUpdates.completedAt = new Date();
    }
    
    const result = await db.update(tasks)
      .set(processedUpdates)
      .where(eq(tasks.id, id))
      .returning();
    return result[0];
  }

  async deleteTask(id: number): Promise<boolean> {
    await db.delete(tasks).where(eq(tasks.id, id));
    return true;
  }

  async getTasksByMinistry(ministryId: number): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(eq(tasks.ministryId, ministryId));
  }

  async getTasksByStatus(status: TaskStatus): Promise<Task[]> {
    return await db.select()
      .from(tasks)
      .where(eq(tasks.status, status));
  }

  async getTasksByAssignee(userId: number): Promise<Task[]> {
    // Esta é uma consulta complexa, pois precisamos verificar se userId está no array assignees
    // Como o Drizzle não tem um operador ARRAY_CONTAINS, precisamos fazer isso manualmente
    const allTasks = await db.select().from(tasks);
    return allTasks.filter(task => task.assignees?.includes(userId));
  }

  // Canteen Menu operations
  async getCanteenMenu(id: number): Promise<CanteenMenu | undefined> {
    const results = await db.select().from(canteenMenus).where(eq(canteenMenus.id, id));
    return results[0];
  }

  async createCanteenMenu(menu: InsertCanteenMenu): Promise<CanteenMenu> {
    // Garantir que status seja do tipo ServiceStatus
    const validMenu = {
      ...menu,
      status: menu.status ? (menu.status as ServiceStatus) : 'pending' as ServiceStatus,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(canteenMenus).values(validMenu).returning();
    return result[0];
  }

  async updateCanteenMenu(id: number, updates: Partial<InsertCanteenMenu>): Promise<CanteenMenu | undefined> {
    // Processar atualizações garantindo os tipos corretos
    const processedUpdates = {...updates};
    if (typeof updates.status === 'string') {
      processedUpdates.status = updates.status as ServiceStatus;
    }
    
    const result = await db.update(canteenMenus)
      .set({
        ...processedUpdates,
        updatedAt: new Date()
      })
      .where(eq(canteenMenus.id, id))
      .returning();
    return result[0];
  }

  async deleteCanteenMenu(id: number): Promise<boolean> {
    await db.delete(canteenMenus).where(eq(canteenMenus.id, id));
    return true;
  }

  async getCanteenMenusByService(serviceId: number): Promise<CanteenMenu[]> {
    return await db.select()
      .from(canteenMenus)
      .where(eq(canteenMenus.serviceId, serviceId));
  }

  // Access Rules operations
  async getAccessRule(id: number): Promise<AccessRule | undefined> {
    const results = await db.select().from(accessRules).where(eq(accessRules.id, id));
    return results[0];
  }

  async createAccessRule(rule: InsertAccessRule): Promise<AccessRule> {
    // Garantir que canEdit seja sempre um booleano
    const validRule = {
      ...rule,
      canEdit: rule.canEdit !== undefined ? rule.canEdit : false
    };
    
    const result = await db.insert(accessRules).values(validRule).returning();
    return result[0];
  }

  async getAccessRulesByMinistry(ministryId: number): Promise<AccessRule[]> {
    return await db.select()
      .from(accessRules)
      .where(eq(accessRules.fromMinistryId, ministryId));
  }

  async canAccessMinistry(fromMinistryId: number, toMinistryId: number): Promise<boolean> {
    if (fromMinistryId === toMinistryId) return true;
    
    const rules = await db.select()
      .from(accessRules)
      .where(
        and(
          eq(accessRules.fromMinistryId, fromMinistryId),
          eq(accessRules.toMinistryId, toMinistryId)
        )
      );
    
    return rules.length > 0;
  }
}