import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertServiceSchema,
  insertScheduleSchema, 
  insertContestationSchema, 
  insertTaskSchema, 
  insertCanteenMenuSchema,
  RoleType,
  ServiceStatus
} from "@shared/schema";
import session from "express-session";
import { z } from "zod";
import MemoryStore from "memorystore";

// Ampliar a definição do SessionData para incluir nossos campos personalizados
declare module "express-session" {
  interface SessionData {
    userId?: number;
    userRole?: RoleType;
    ministryId?: number;
  }
}

const SessionStore = MemoryStore(session);

// Authentication middleware
const authenticateUser = (req: Request, res: Response, next: Function) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
};

// Authorization middleware for leaders only
const requireLeaderRole = (req: Request, res: Response, next: Function) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  if (req.session.userRole !== "leader") {
    return res.status(403).json({ message: "Forbidden: Only leaders can perform this action" });
  }
  
  next();
};

// Middleware to check if user is a leader or belongs to the ministry
const canManageMinistry = (ministryIdParam: string = "ministryId") => {
  return async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Get ministry ID from URL parameters
    const ministryId = parseInt(req.params[ministryIdParam]);
    if (isNaN(ministryId)) {
      return res.status(400).json({ message: "Invalid ministry ID" });
    }
    
    // Get user from database
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    // Check if user is a leader or belongs to this ministry
    const isLeader = user.role === "leader";
    const isInMinistry = user.ministryId === ministryId;
    
    if (!isLeader && !isInMinistry) {
      return res.status(403).json({ message: "Forbidden: You don't have permission to manage this ministry" });
    }
    
    // If user is not a leader but belongs to the ministry, they can only view
    if (!isLeader && req.method !== "GET") {
      return res.status(403).json({ message: "Forbidden: Only leaders can modify ministry data" });
    }
    
    next();
  };
};

// Authorization middleware for specific ministry
const authorizeMinistry = (ministryId: number, requireLeader: boolean = false) => {
  return async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Check if user is from the specified ministry or has access to it
    const hasAccess = user.ministryId === ministryId ||
                     await storage.canAccessMinistry(user.ministryId!, ministryId);
    
    // Check if leader role is required
    const isAuthorized = hasAccess && (!requireLeader || user.role === "leader");

    if (!isAuthorized) {
      return res.status(403).json({ message: "Forbidden" });
    }

    next();
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(
    session({
      store: new SessionStore({
        checkPeriod: 86400000 // Prune expired entries every 24h
      }),
      secret: "colaborachurch-secret-key", // In production this should be in env variables
      resave: true,
      saveUninitialized: true,
      cookie: {
        secure: false, // Set to true in production with HTTPS
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: 'lax'
      }
    })
  );

  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) { // In production use bcrypt to compare passwords
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set session
      req.session.userId = user.id;
      req.session.userRole = user.role;
      req.session.ministryId = user.ministryId;

      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Debug route to check session
  app.get("/api/auth/debug", (req, res) => {
    res.json({
      sessionExists: !!req.session,
      sessionId: req.session.id,
      userId: req.session.userId || null,
      cookieMaxAge: req.session.cookie?.maxAge
    });
  });

  app.get("/api/auth/me", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Get current user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/ministries/:ministryId/users", authenticateUser, async (req, res) => {
    try {
      const ministryId = parseInt(req.params.ministryId);
      const users = await storage.getUsersByMinistry(ministryId);
      
      // Filter out passwords
      const usersWithoutPasswords = users.map(user => {
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      return res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      console.error("Get ministry users error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Ministry routes
  app.get("/api/ministries", authenticateUser, async (req, res) => {
    try {
      const ministries = await storage.getMinistries();
      return res.status(200).json(ministries);
    } catch (error) {
      console.error("Get ministries error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/ministries/:id", authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const ministry = await storage.getMinistry(id);
      
      if (!ministry) {
        return res.status(404).json({ message: "Ministry not found" });
      }
      
      return res.status(200).json(ministry);
    } catch (error) {
      console.error("Get ministry error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/ministries/slug/:slug", authenticateUser, async (req, res) => {
    try {
      const { slug } = req.params;
      const ministry = await storage.getMinistryBySlug(slug);
      
      if (!ministry) {
        return res.status(404).json({ message: "Ministry not found" });
      }
      
      return res.status(200).json(ministry);
    } catch (error) {
      console.error("Get ministry by slug error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Service routes
  app.get("/api/services", authenticateUser, async (req, res) => {
    try {
      const services = await storage.getServices();
      return res.status(200).json(services);
    } catch (error) {
      console.error("Get services error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/services/upcoming", authenticateUser, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const services = await storage.getUpcomingServices(limit);
      return res.status(200).json(services);
    } catch (error) {
      console.error("Get upcoming services error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Criar novo culto (service)
  app.post("/api/services", authenticateUser, requireLeaderRole, async (req, res) => {
    try {
      console.log("Received service data:", JSON.stringify(req.body, null, 2));
      
      // Verificar se a data é uma string ISO e convertê-la para objeto Date
      let serviceDataFixed = { ...req.body };
      if (typeof req.body.date === 'string') {
        serviceDataFixed.date = new Date(req.body.date);
      }
      
      // Tentar fazer parse dos dados ajustados
      try {
        const serviceData = insertServiceSchema.parse(serviceDataFixed);
        
        // Calcular o dia da semana com base na data
        const date = new Date(serviceData.date);
        const diasSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
        const dayOfWeek = diasSemana[date.getDay()];
        
        // Adicionar o dia da semana aos dados do serviço
        const serviceWithDayOfWeek = {
          ...serviceData,
          dayOfWeek
        };
        
        console.log("Service data after parsing:", JSON.stringify(serviceWithDayOfWeek, null, 2));
        
        const service = await storage.createService(serviceWithDayOfWeek);
        
        // Enviar notificação para o webhook externo
        try {
          const { NotificationService } = await import('./services/notification-service');
          await NotificationService.notifyServiceChange('create', service);
        } catch (notificationError) {
          console.error("Erro ao enviar notificação:", notificationError);
          // Não interrompemos o fluxo principal se a notificação falhar
        }
        
        return res.status(201).json(service);
      } catch (parseError) {
        console.error("Erro ao validar dados do culto:", parseError);
        if (parseError instanceof z.ZodError) {
          return res.status(400).json({ 
            message: "Dados inválidos para o culto", 
            errors: parseError.errors,
            fieldIssues: parseError.format()
          });
        }
        throw parseError; // Passar para o próximo catch
      }
    } catch (error) {
      console.error("Erro ao criar culto:", error);
      return res.status(500).json({ message: "Erro interno do servidor", error: String(error) });
    }
  });
  
  // Obter culto específico
  app.get("/api/services/:id", authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const service = await storage.getService(id);
      if (!service) {
        return res.status(404).json({ message: "Culto não encontrado" });
      }
      
      return res.status(200).json(service);
    } catch (error) {
      console.error("Erro ao buscar culto:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
  
  // Atualizar culto
  app.put("/api/services/:id", authenticateUser, requireLeaderRole, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const service = await storage.getService(id);
      if (!service) {
        return res.status(404).json({ message: "Culto não encontrado" });
      }
      
      // Verificar dados atualizados
      const serviceData = insertServiceSchema.parse(req.body);
      
      // Calcular o dia da semana com base na data atualizada (se a data for alterada)
      let dayOfWeek = service.dayOfWeek;
      if (serviceData.date) {
        const date = new Date(serviceData.date);
        const diasSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
        dayOfWeek = diasSemana[date.getDay()];
      }
      
      // Atualizar o culto com o dia da semana calculado
      const updatedServiceData = {
        ...serviceData,
        dayOfWeek
      };
      
      const updatedService = await storage.updateService(id, updatedServiceData);
      
      // Enviar notificação para o webhook externo
      try {
        const { NotificationService } = await import('./services/notification-service');
        await NotificationService.notifyServiceChange('update', updatedService);
      } catch (notificationError) {
        console.error("Erro ao enviar notificação:", notificationError);
        // Não interrompemos o fluxo principal se a notificação falhar
      }
      
      return res.status(200).json(updatedService);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados inválidos para o culto", errors: error.errors });
      }
      console.error("Erro ao atualizar culto:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Schedule routes
  app.get("/api/ministries/:ministryId/schedules", authenticateUser, async (req, res) => {
    try {
      const ministryId = parseInt(req.params.ministryId);
      
      // Check if user is authorized to view this ministry's schedules
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const canAccess = user.ministryId === ministryId || 
                       await storage.canAccessMinistry(user.ministryId!, ministryId);
      
      if (!canAccess) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const schedules = await storage.getSchedulesByMinistry(ministryId);
      
      // Fetch service details for each schedule
      const schedulesWithServiceDetails = await Promise.all(
        schedules.map(async (schedule) => {
          const service = await storage.getService(schedule.serviceId);
          return { ...schedule, service };
        })
      );
      
      return res.status(200).json(schedulesWithServiceDetails);
    } catch (error) {
      console.error("Get ministry schedules error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/ministries/:ministryId/schedules", authenticateUser, requireLeaderRole, async (req, res) => {
    try {
      const ministryId = parseInt(req.params.ministryId);
      const user = await storage.getUser(req.session.userId!);
      
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const scheduleData = insertScheduleSchema.parse({
        ...req.body,
        ministryId,
        leaderId: user.id
      });
      
      const schedule = await storage.createSchedule(scheduleData);
      
      // Enviar notificação para o webhook externo
      try {
        const { NotificationService } = await import('./services/notification-service');
        await NotificationService.notifyScheduleChange('create', schedule);
      } catch (notificationError) {
        console.error("Erro ao enviar notificação:", notificationError);
        // Não interrompemos o fluxo principal se a notificação falhar
      }
      
      return res.status(201).json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid schedule data", errors: error.errors });
      }
      console.error("Create schedule error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/schedules/:id", authenticateUser, requireLeaderRole, async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.id);
      const schedule = await storage.getSchedule(scheduleId);
      
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      // Verificar se o usuário pertence ao mesmo ministério da escala
      const user = await storage.getUser(req.session.userId!);
      if (!user || user.ministryId !== schedule.ministryId) {
        return res.status(403).json({ message: "Você não tem permissão para editar escalas de outros ministérios" });
      }
      
      const updatedSchedule = await storage.updateSchedule(scheduleId, req.body);
      
      // Enviar notificação para o webhook externo
      try {
        const { NotificationService } = await import('./services/notification-service');
        await NotificationService.notifyScheduleChange('update', updatedSchedule);
      } catch (notificationError) {
        console.error("Erro ao enviar notificação:", notificationError);
        // Não interrompemos o fluxo principal se a notificação falhar
      }
      
      return res.status(200).json(updatedSchedule);
    } catch (error) {
      console.error("Update schedule error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/schedules/:id", authenticateUser, requireLeaderRole, async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.id);
      const schedule = await storage.getSchedule(scheduleId);
      
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      // Verificar se o usuário pertence ao mesmo ministério da escala
      const user = await storage.getUser(req.session.userId!);
      if (!user || user.ministryId !== schedule.ministryId) {
        return res.status(403).json({ message: "Você não tem permissão para excluir escalas de outros ministérios" });
      }
      
      const success = await storage.deleteSchedule(scheduleId);
      if (success) {
        return res.status(204).send();
      } else {
        return res.status(500).json({ message: "Falha ao excluir escala" });
      }
    } catch (error) {
      console.error("Delete schedule error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Contestation routes
  app.post("/api/schedules/:scheduleId/contestations", authenticateUser, async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.scheduleId);
      const schedule = await storage.getSchedule(scheduleId);
      
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      // Check if user is in this schedule's ministry
      const user = await storage.getUser(req.session.userId!);
      if (!user || user.ministryId !== schedule.ministryId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const contestationData = insertContestationSchema.parse({
        ...req.body,
        scheduleId,
        userId: user.id
      });
      
      const contestation = await storage.createContestation(contestationData);
      return res.status(201).json(contestation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid contestation data", errors: error.errors });
      }
      console.error("Create contestation error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/schedules/:scheduleId/contestations", authenticateUser, async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.scheduleId);
      const schedule = await storage.getSchedule(scheduleId);
      
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      // Check if user is authorized to view contestations
      const user = await storage.getUser(req.session.userId!);
      if (!user || (user.ministryId !== schedule.ministryId && user.role !== "leader")) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const contestations = await storage.getContestationsBySchedule(scheduleId);
      return res.status(200).json(contestations);
    } catch (error) {
      console.error("Get schedule contestations error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/contestations/:id", authenticateUser, async (req, res) => {
    try {
      const contestationId = parseInt(req.params.id);
      const contestation = await storage.getContestation(contestationId);
      
      if (!contestation) {
        return res.status(404).json({ message: "Contestation not found" });
      }
      
      const schedule = await storage.getSchedule(contestation.scheduleId);
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      // Check if user is authorized to update contestation status
      const user = await storage.getUser(req.session.userId!);
      if (!user || user.ministryId !== schedule.ministryId || user.role !== "leader") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { status } = req.body;
      if (!status || !["approved", "rejected", "pending"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedContestation = await storage.updateContestation(contestationId, status);
      return res.status(200).json(updatedContestation);
    } catch (error) {
      console.error("Update contestation error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Task routes
  app.get("/api/ministries/:ministryId/tasks", authenticateUser, async (req, res) => {
    try {
      const ministryId = parseInt(req.params.ministryId);
      
      // Check if user is authorized to view tasks
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const canAccess = user.ministryId === ministryId || 
                        await storage.canAccessMinistry(user.ministryId!, ministryId);
      
      if (!canAccess) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const tasks = await storage.getTasksByMinistry(ministryId);
      
      // Get all users mentioned in tasks to include in response
      const userIds = new Set<number>();
      tasks.forEach(task => {
        userIds.add(task.createdBy);
        task.assignees.forEach(userId => userIds.add(userId));
      });
      
      const users = await Promise.all(
        Array.from(userIds).map(async userId => {
          const user = await storage.getUser(userId);
          if (user) {
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
          }
          return null;
        })
      );
      
      // Filter out nulls
      const validUsers = users.filter(user => user !== null);
      
      return res.status(200).json({
        tasks,
        users: validUsers
      });
    } catch (error) {
      console.error("Get ministry tasks error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/ministries/:ministryId/tasks", authenticateUser, requireLeaderRole, async (req, res) => {
    try {
      const ministryId = parseInt(req.params.ministryId);
      
      // Check if user is in this ministry
      const user = await storage.getUser(req.session.userId!);
      if (!user || user.ministryId !== ministryId) {
        return res.status(403).json({ message: "Você não pode criar tarefas para outros ministérios" });
      }
      
      const taskData = insertTaskSchema.parse({
        ...req.body,
        ministryId,
        createdBy: user.id
      });
      
      const task = await storage.createTask(taskData);
      return res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Dados de tarefa inválidos", errors: error.errors });
      }
      console.error("Create task error:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/tasks/:id", authenticateUser, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Check if user is authorized to update this task
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Only task creator or ministry leader can update tasks
      const isTaskCreator = task.createdBy === user.id;
      const isMinistryLeader = user.ministryId === task.ministryId && user.role === "leader";
      const isAssignee = task.assignees.includes(user.id);
      
      if (!isTaskCreator && !isMinistryLeader && !isAssignee) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // If user is just an assignee, they can only update status
      if (isAssignee && !isTaskCreator && !isMinistryLeader) {
        if (Object.keys(req.body).some(key => key !== "status")) {
          return res.status(403).json({ message: "You can only update task status" });
        }
      }
      
      const updatedTask = await storage.updateTask(taskId, req.body);
      return res.status(200).json(updatedTask);
    } catch (error) {
      console.error("Update task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/tasks/:id", authenticateUser, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Check if user is authorized to delete this task
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Only task creator or ministry leader can delete tasks
      const isTaskCreator = task.createdBy === user.id;
      const isMinistryLeader = user.ministryId === task.ministryId && user.role === "leader";
      
      if (!isTaskCreator && !isMinistryLeader) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const success = await storage.deleteTask(taskId);
      if (success) {
        return res.status(204).send();
      } else {
        return res.status(500).json({ message: "Failed to delete task" });
      }
    } catch (error) {
      console.error("Delete task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Canteen Menu routes
  app.get("/api/canteenmenus", authenticateUser, async (req, res) => {
    try {
      const serviceId = req.query.serviceId ? parseInt(req.query.serviceId as string) : undefined;
      let menus = [];
      
      if (serviceId) {
        menus = await storage.getCanteenMenusByService(serviceId);
      } else {
        // Get all menus (this would need implementation in storage)
        // For now, just return empty array
        menus = [];
      }
      
      // Enhance menus with service data
      const enhancedMenus = await Promise.all(
        menus.map(async (menu) => {
          const service = await storage.getService(menu.serviceId);
          const responsible = await storage.getUser(menu.responsibleId);
          
          let responsibleName = "Unknown";
          if (responsible) {
            responsibleName = responsible.fullName;
          }
          
          return {
            ...menu,
            service,
            responsibleName
          };
        })
      );
      
      return res.status(200).json(enhancedMenus);
    } catch (error) {
      console.error("Get canteen menus error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/canteenmenus", authenticateUser, async (req, res) => {
    try {
      // Check if user is from Cantina ministry and is a leader
      const user = await storage.getUser(req.session.userId!);
      const cantinaMinistry = await storage.getMinistryBySlug("cantina");
      
      if (!user || !cantinaMinistry || user.ministryId !== cantinaMinistry.id || user.role !== "leader") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const menuData = insertCanteenMenuSchema.parse({
        ...req.body,
        responsibleId: user.id
      });
      
      const menu = await storage.createCanteenMenu(menuData);
      return res.status(201).json(menu);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid menu data", errors: error.errors });
      }
      console.error("Create canteen menu error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/canteenmenus/:id", authenticateUser, async (req, res) => {
    try {
      const menuId = parseInt(req.params.id);
      const menu = await storage.getCanteenMenu(menuId);
      
      if (!menu) {
        return res.status(404).json({ message: "Menu not found" });
      }
      
      // Check if user is from Cantina ministry and is a leader
      const user = await storage.getUser(req.session.userId!);
      const cantinaMinistry = await storage.getMinistryBySlug("cantina");
      
      if (!user || !cantinaMinistry || user.ministryId !== cantinaMinistry.id || user.role !== "leader") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedMenu = await storage.updateCanteenMenu(menuId, req.body);
      return res.status(200).json(updatedMenu);
    } catch (error) {
      console.error("Update canteen menu error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/canteenmenus/:id", authenticateUser, async (req, res) => {
    try {
      const menuId = parseInt(req.params.id);
      const menu = await storage.getCanteenMenu(menuId);
      
      if (!menu) {
        return res.status(404).json({ message: "Menu not found" });
      }
      
      // Check if user is from Cantina ministry and is a leader
      const user = await storage.getUser(req.session.userId!);
      const cantinaMinistry = await storage.getMinistryBySlug("cantina");
      
      if (!user || !cantinaMinistry || user.ministryId !== cantinaMinistry.id || user.role !== "leader") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const success = await storage.deleteCanteenMenu(menuId);
      if (success) {
        return res.status(204).send();
      } else {
        return res.status(500).json({ message: "Failed to delete menu" });
      }
    } catch (error) {
      console.error("Delete canteen menu error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Access rules routes
  app.get("/api/accessrules", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user || !user.ministryId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const accessRules = await storage.getAccessRulesByMinistry(user.ministryId);
      
      // Enhance with ministry details
      const enhancedRules = await Promise.all(
        accessRules.map(async (rule) => {
          const toMinistry = await storage.getMinistry(rule.toMinistryId);
          return {
            ...rule,
            toMinistry
          };
        })
      );
      
      return res.status(200).json(enhancedRules);
    } catch (error) {
      console.error("Get access rules error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard summary data
  app.get("/api/dashboard", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Get upcoming services
      const upcomingServices = await storage.getUpcomingServices(5);
      
      // Get tasks for user's ministry
      let pendingTasks = [];
      let overdueTasks = [];
      
      if (user.ministryId) {
        // Get all pending tasks
        const allPendingTasks = await storage.getTasksByMinistry(user.ministryId);
        
        // Split into pending and overdue
        const now = new Date();
        pendingTasks = allPendingTasks.filter(task => {
          if (task.status !== 'pending') return false;
          return !task.dueDate || new Date(task.dueDate) >= now;
        });
        
        overdueTasks = allPendingTasks.filter(task => {
          if (task.status !== 'pending') return false;
          return task.dueDate && new Date(task.dueDate) < now;
        });
      }
      
      // Get ministry schedules
      let userSchedules = [];
      if (user.ministryId) {
        const allSchedules = await storage.getSchedulesByMinistry(user.ministryId);
        
        // Get only future schedules
        const now = new Date();
        userSchedules = await Promise.all(
          allSchedules
            .filter(async (schedule) => {
              const service = await storage.getService(schedule.serviceId);
              return service && new Date(service.date) >= now;
            })
            .sort(async (a, b) => {
              const serviceA = await storage.getService(a.serviceId);
              const serviceB = await storage.getService(b.serviceId);
              if (!serviceA || !serviceB) return 0;
              
              return new Date(serviceA.date).getTime() - new Date(serviceB.date).getTime();
            })
            .slice(0, 3)
            .map(async (schedule) => {
              const service = await storage.getService(schedule.serviceId);
              return { ...schedule, service };
            })
        );
      }
      
      // Get accessible ministries
      let accessibleMinistries = [];
      if (user.ministryId) {
        const accessRules = await storage.getAccessRulesByMinistry(user.ministryId);
        
        accessibleMinistries = await Promise.all(
          accessRules.map(async (rule) => {
            const ministry = await storage.getMinistry(rule.toMinistryId);
            return {
              ...ministry,
              canEdit: rule.canEdit
            };
          })
        );
      }
      
      return res.status(200).json({
        upcomingServices,
        pendingTasks: pendingTasks.length,
        overdueTasks: overdueTasks.length,
        userSchedules,
        accessibleMinistries
      });
      
    } catch (error) {
      console.error("Get dashboard data error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
