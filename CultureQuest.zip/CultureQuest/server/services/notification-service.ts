import axios from 'axios';
import { Service, Schedule, Task, CanteenMenu, Contestation } from '@shared/schema';

// URL do webhook fornecido pelo usuário
const WEBHOOK_URL = 'https://patricgomes.app.n8n.cloud/webhook-test/0b93fb2d-fead-4987-8a74-10f09e732ab2';

interface WebhookPayload {
  actionType: 'create' | 'update' | 'delete';
  resourceType: 'service' | 'schedule' | 'task' | 'canteenMenu' | 'contestation';
  data: any;
  timestamp: string;
}

/**
 * Serviço responsável por enviar notificações para o webhook externo
 */
export const NotificationService = {
  /**
   * Envia uma notificação para o webhook quando um culto é criado ou atualizado
   */
  async notifyServiceChange(
    action: 'create' | 'update',
    service: Service
  ): Promise<void> {
    const payload: WebhookPayload = {
      actionType: action,
      resourceType: 'service',
      data: service,
      timestamp: new Date().toISOString()
    };
    
    await sendWebhookNotification(payload);
  },

  /**
   * Envia uma notificação para o webhook quando uma escala é criada ou atualizada
   */
  async notifyScheduleChange(
    action: 'create' | 'update' | 'delete',
    schedule: Schedule
  ): Promise<void> {
    const payload: WebhookPayload = {
      actionType: action,
      resourceType: 'schedule',
      data: schedule,
      timestamp: new Date().toISOString()
    };
    
    await sendWebhookNotification(payload);
  },

  /**
   * Envia uma notificação para o webhook quando uma tarefa é criada ou atualizada
   */
  async notifyTaskChange(
    action: 'create' | 'update' | 'delete',
    task: Task
  ): Promise<void> {
    const payload: WebhookPayload = {
      actionType: action,
      resourceType: 'task',
      data: task,
      timestamp: new Date().toISOString()
    };
    
    await sendWebhookNotification(payload);
  },

  /**
   * Envia uma notificação para o webhook quando o cardápio da cantina é criado ou atualizado
   */
  async notifyCanteenMenuChange(
    action: 'create' | 'update' | 'delete',
    menu: CanteenMenu
  ): Promise<void> {
    const payload: WebhookPayload = {
      actionType: action,
      resourceType: 'canteenMenu',
      data: menu,
      timestamp: new Date().toISOString()
    };
    
    await sendWebhookNotification(payload);
  },

  /**
   * Envia uma notificação para o webhook quando uma contestação é criada ou atualizada
   */
  async notifyContestationChange(
    action: 'create' | 'update',
    contestation: Contestation
  ): Promise<void> {
    const payload: WebhookPayload = {
      actionType: action,
      resourceType: 'contestation',
      data: contestation,
      timestamp: new Date().toISOString()
    };
    
    await sendWebhookNotification(payload);
  }
};

/**
 * Função auxiliar para enviar a notificação para o webhook
 */
async function sendWebhookNotification(payload: WebhookPayload): Promise<void> {
  try {
    const response = await axios.post(WEBHOOK_URL, payload);
    console.log(`Notificação enviada com sucesso para o webhook. Status: ${response.status}`);
  } catch (error) {
    console.error('Erro ao enviar notificação para o webhook:', error);
    // Não lançamos o erro aqui para não afetar o fluxo principal da aplicação
  }
}