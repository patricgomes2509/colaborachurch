import {
  users, User, InsertUser,
  userMinistries, UserMinistry, InsertUserMinistry,
  ministries, Ministry, InsertMinistry,
  services, Service, InsertService,
  schedules, Schedule, InsertSchedule,
  contestations, Contestation, InsertContestation,
  tasks, Task, InsertTask,
  canteenMenus, CanteenMenu, InsertCanteenMenu,
  accessRules, AccessRule, InsertAccessRule,
  birthdayNotifications, BirthdayNotification, InsertBirthdayNotification,
  TaskStatus
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  getUsersByMinistry(ministryId: number): Promise<User[]>;
  getUsersWithBirthdays(month: number): Promise<User[]>;
  getUsersWithUpcomingBirthdays(days: number): Promise<User[]>;
  
  // User-Ministry operations
  addUserToMinistry(userMinistry: InsertUserMinistry): Promise<UserMinistry>;
  removeUserFromMinistry(userId: number, ministryId: number): Promise<boolean>;
  getUserMinistries(userId: number): Promise<Ministry[]>;
  getMinistryUsers(ministryId: number): Promise<User[]>;
  
  // Birthday Notification operations
  createBirthdayNotification(notification: InsertBirthdayNotification): Promise<BirthdayNotification>;
  getBirthdayNotifications(viewed?: boolean): Promise<BirthdayNotification[]>;
  markBirthdayNotificationAsViewed(id: number): Promise<BirthdayNotification | undefined>;

  // Ministry operations
  getMinistry(id: number): Promise<Ministry | undefined>;
  getMinistryBySlug(slug: string): Promise<Ministry | undefined>;
  createMinistry(ministry: InsertMinistry): Promise<Ministry>;
  getMinistries(): Promise<Ministry[]>;

  // Service operations
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, updates: Partial<InsertService>): Promise<Service | undefined>;
  getServices(): Promise<Service[]>;
  getUpcomingServices(limit?: number): Promise<Service[]>;

  // Schedule operations
  getSchedule(id: number): Promise<Schedule | undefined>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, schedule: Partial<InsertSchedule>): Promise<Schedule | undefined>;
  deleteSchedule(id: number): Promise<boolean>;
  getSchedulesByMinistry(ministryId: number): Promise<Schedule[]>;
  getSchedulesByService(serviceId: number): Promise<Schedule[]>;

  // Contestation operations
  getContestation(id: number): Promise<Contestation | undefined>;
  createContestation(contestation: InsertContestation): Promise<Contestation>;
  updateContestation(id: number, status: string): Promise<Contestation | undefined>;
  getContestationsBySchedule(scheduleId: number): Promise<Contestation[]>;
  getContestationsByUser(userId: number): Promise<Contestation[]>;

  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  getTasksByMinistry(ministryId: number): Promise<Task[]>;
  getTasksByStatus(status: TaskStatus): Promise<Task[]>;
  getTasksByAssignee(userId: number): Promise<Task[]>;

  // Canteen Menu operations
  getCanteenMenu(id: number): Promise<CanteenMenu | undefined>;
  createCanteenMenu(menu: InsertCanteenMenu): Promise<CanteenMenu>;
  updateCanteenMenu(id: number, menu: Partial<InsertCanteenMenu>): Promise<CanteenMenu | undefined>;
  deleteCanteenMenu(id: number): Promise<boolean>;
  getCanteenMenusByService(serviceId: number): Promise<CanteenMenu[]>;

  // Access Rules operations
  getAccessRule(id: number): Promise<AccessRule | undefined>;
  createAccessRule(rule: InsertAccessRule): Promise<AccessRule>;
  getAccessRulesByMinistry(ministryId: number): Promise<AccessRule[]>;
  canAccessMinistry(fromMinistryId: number, toMinistryId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private userMinistries: Map<number, UserMinistry>;
  private ministries: Map<number, Ministry>;
  private services: Map<number, Service>;
  private schedules: Map<number, Schedule>;
  private contestations: Map<number, Contestation>;
  private tasks: Map<number, Task>;
  private canteenMenus: Map<number, CanteenMenu>;
  private accessRules: Map<number, AccessRule>;
  private birthdayNotifications: Map<number, BirthdayNotification>;

  private userCurrentId: number;
  private userMinistryCurrentId: number;
  private ministryCurrentId: number;
  private serviceCurrentId: number;
  private scheduleCurrentId: number;
  private contestationCurrentId: number;
  private taskCurrentId: number;
  private canteenMenuCurrentId: number;
  private accessRuleCurrentId: number;
  private birthdayNotificationCurrentId: number;

  constructor() {
    this.users = new Map();
    this.userMinistries = new Map();
    this.ministries = new Map();
    this.services = new Map();
    this.schedules = new Map();
    this.contestations = new Map();
    this.tasks = new Map();
    this.canteenMenus = new Map();
    this.accessRules = new Map();
    this.birthdayNotifications = new Map();

    this.userCurrentId = 1;
    this.userMinistryCurrentId = 1;
    this.ministryCurrentId = 1;
    this.serviceCurrentId = 1;
    this.scheduleCurrentId = 1;
    this.contestationCurrentId = 1;
    this.taskCurrentId = 1;
    this.canteenMenuCurrentId = 1;
    this.accessRuleCurrentId = 1;
    this.birthdayNotificationCurrentId = 1;

    // Initialize with default data
    this.initializeData();
  }

  private initializeData() {
    // Create default ministries
    const ministries = [
      { name: "Louvor e Adoração", colorClass: "ministry-louvor", slug: "louvor" },
      { name: "Pregadores", colorClass: "ministry-pregadores", slug: "pregadores" },
      { name: "Mídia e Eventos", colorClass: "ministry-midia", slug: "midia" },
      { name: "Kids", colorClass: "ministry-kids", slug: "kids" },
      { name: "Obreiros", colorClass: "ministry-obreiros", slug: "obreiros" },
      { name: "Cantina", colorClass: "ministry-cantina", slug: "cantina" },
      { name: "EBD", colorClass: "ministry-ebd", slug: "ebd" },
      { name: "Recepção", colorClass: "ministry-recepcao", slug: "recepcao" }
    ];

    ministries.forEach(m => this.createMinistry(m));

    // Create access rules between ministries
    // Louvor can see Mídia and Pregadores
    this.createAccessRule({ fromMinistryId: 1, toMinistryId: 3, canEdit: false });
    this.createAccessRule({ fromMinistryId: 1, toMinistryId: 2, canEdit: false });
    
    // Pregadores can see Mídia
    this.createAccessRule({ fromMinistryId: 2, toMinistryId: 3, canEdit: false });
    
    // Mídia can see Louvor and Pregadores
    this.createAccessRule({ fromMinistryId: 3, toMinistryId: 1, canEdit: false });
    this.createAccessRule({ fromMinistryId: 3, toMinistryId: 2, canEdit: false });
    
    // Mídia can see Cantina
    this.createAccessRule({ fromMinistryId: 3, toMinistryId: 6, canEdit: false });

    // Create test user (João Silva as leader of Louvor)
    this.createUser({
      username: "joao.silva",
      password: "password", // In a real app, this would be hashed
      fullName: "João Silva",
      role: "leader",
      ministryId: 1
    });
    
    // Create upcoming services
    const today = new Date();
    const dayNames = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
    
    // Sunday service (in the future)
    const nextSunday = new Date(today);
    nextSunday.setDate(today.getDate() + (7 - today.getDay()) % 7);
    this.createService({
      date: nextSunday,
      dayOfWeek: "Domingo",
      name: "Culto da Noite",
      time: "19:00",
      status: "pending"
    });
    
    // Wednesday service (in the future)
    const nextWednesday = new Date(today);
    nextWednesday.setDate(today.getDate() + (3 + 7 - today.getDay()) % 7);
    this.createService({
      date: nextWednesday,
      dayOfWeek: "Quarta-feira",
      name: "Culto de Oração",
      time: "19:30",
      status: "pending"
    });
    
    // Previous services (for history)
    const lastSunday = new Date(today);
    lastSunday.setDate(today.getDate() - (today.getDay() || 7));
    this.createService({
      date: lastSunday,
      dayOfWeek: "Domingo",
      name: "Culto da Noite",
      time: "19:00",
      status: "completed"
    });
    
    const lastWednesday = new Date(today);
    lastWednesday.setDate(today.getDate() - ((today.getDay() + 4) % 7 || 7));
    this.createService({
      date: lastWednesday,
      dayOfWeek: "Quarta-feira",
      name: "Culto de Oração",
      time: "19:30",
      status: "completed"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    // Garantir que campos opcionais tenham valores null em vez de undefined
    const user: User = { 
      ...insertUser, 
      id,
      email: insertUser.email || null,
      phone: insertUser.phone || null,
      cpf: insertUser.cpf || null,
      birthDate: insertUser.birthDate || null,
      bio: insertUser.bio || null,
      avatarUrl: insertUser.avatarUrl || null
    };
    this.users.set(id, user);
    
    // Se um ministryId foi fornecido, adicionar automaticamente 
    // o usuário a esse ministério na tabela de relacionamento
    if (insertUser.ministryId) {
      await this.addUserToMinistry({
        userId: id,
        ministryId: insertUser.ministryId
      });
    }
    
    return user;
  }
  
  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...updates,
      // Garantir que os campos opcionais mantenham valores null em vez de undefined
      email: updates.email !== undefined ? updates.email : user.email,
      phone: updates.phone !== undefined ? updates.phone : user.phone,
      cpf: updates.cpf !== undefined ? updates.cpf : user.cpf,
      birthDate: updates.birthDate !== undefined ? updates.birthDate : user.birthDate,
      bio: updates.bio !== undefined ? updates.bio : user.bio,
      avatarUrl: updates.avatarUrl !== undefined ? updates.avatarUrl : user.avatarUrl
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUsersByMinistry(ministryId: number): Promise<User[]> {
    // Buscar usuários diretamente pela ministryId principal
    const directUsers = Array.from(this.users.values()).filter(
      (user) => user.ministryId === ministryId
    );
    
    // Buscar usuários através da tabela de relacionamento
    const userMinistryRelations = Array.from(this.userMinistries.values()).filter(
      (relation) => relation.ministryId === ministryId
    );
    
    const relatedUserIds = userMinistryRelations.map(relation => relation.userId);
    const relatedUsers = Array.from(this.users.values()).filter(
      (user) => relatedUserIds.includes(user.id) && !directUsers.some(du => du.id === user.id)
    );
    
    // Combinar ambos os conjuntos de usuários
    return [...directUsers, ...relatedUsers];
  }
  
  async getUsersWithBirthdays(month: number): Promise<User[]> {
    // Mês é 1-12 (Janeiro-Dezembro)
    return Array.from(this.users.values()).filter(user => {
      if (!user.birthDate) return false;
      const birthDate = new Date(user.birthDate);
      return birthDate.getMonth() + 1 === month;
    });
  }
  
  async getUsersWithUpcomingBirthdays(days: number): Promise<User[]> {
    const today = new Date();
    const futureDate = new Date(today);
    futureDate.setDate(today.getDate() + days);
    
    return Array.from(this.users.values()).filter(user => {
      if (!user.birthDate) return false;
      
      const birthDate = new Date(user.birthDate);
      const thisYearBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
      
      // Se o aniversário já passou este ano, considerar o aniversário do próximo ano
      if (thisYearBirthday < today) {
        thisYearBirthday.setFullYear(today.getFullYear() + 1);
      }
      
      // Verificar se o aniversário está dentro do período especificado
      return thisYearBirthday <= futureDate;
    });
  }
  
  // User-Ministry operations
  async addUserToMinistry(userMinistry: InsertUserMinistry): Promise<UserMinistry> {
    const id = this.userMinistryCurrentId++;
    const relation: UserMinistry = { ...userMinistry, id };
    this.userMinistries.set(id, relation);
    return relation;
  }
  
  async removeUserFromMinistry(userId: number, ministryId: number): Promise<boolean> {
    const relationToRemove = Array.from(this.userMinistries.values()).find(
      (relation) => relation.userId === userId && relation.ministryId === ministryId
    );
    
    if (!relationToRemove) return false;
    
    return this.userMinistries.delete(relationToRemove.id);
  }
  
  async getUserMinistries(userId: number): Promise<Ministry[]> {
    // Obter IDs de ministérios do usuário através da tabela de relacionamento
    const ministryIds = Array.from(this.userMinistries.values())
      .filter(relation => relation.userId === userId)
      .map(relation => relation.ministryId);
    
    // Adicionar o ministério principal se existir
    const user = this.users.get(userId);
    if (user && user.ministryId && !ministryIds.includes(user.ministryId)) {
      ministryIds.push(user.ministryId);
    }
    
    // Retornar os ministérios correspondentes
    return Array.from(this.ministries.values())
      .filter(ministry => ministryIds.includes(ministry.id));
  }
  
  async getMinistryUsers(ministryId: number): Promise<User[]> {
    // Método para compatibilidade, use getUsersByMinistry
    return this.getUsersByMinistry(ministryId);
  }
  
  // Birthday Notification operations
  async createBirthdayNotification(notification: InsertBirthdayNotification): Promise<BirthdayNotification> {
    const id = this.birthdayNotificationCurrentId++;
    const now = new Date();
    const newNotification: BirthdayNotification = {
      ...notification,
      id,
      notifiedDate: now,
      viewed: false
    };
    
    this.birthdayNotifications.set(id, newNotification);
    return newNotification;
  }
  
  async getBirthdayNotifications(viewed?: boolean): Promise<BirthdayNotification[]> {
    if (viewed === undefined) {
      return Array.from(this.birthdayNotifications.values());
    }
    
    return Array.from(this.birthdayNotifications.values())
      .filter(notification => notification.viewed === viewed);
  }
  
  async markBirthdayNotificationAsViewed(id: number): Promise<BirthdayNotification | undefined> {
    const notification = this.birthdayNotifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification: BirthdayNotification = {
      ...notification,
      viewed: true
    };
    
    this.birthdayNotifications.set(id, updatedNotification);
    return updatedNotification;
  }

  // Ministry operations
  async getMinistry(id: number): Promise<Ministry | undefined> {
    return this.ministries.get(id);
  }

  async getMinistryBySlug(slug: string): Promise<Ministry | undefined> {
    return Array.from(this.ministries.values()).find(
      (ministry) => ministry.slug === slug
    );
  }

  async createMinistry(insertMinistry: InsertMinistry): Promise<Ministry> {
    const id = this.ministryCurrentId++;
    const ministry: Ministry = { ...insertMinistry, id };
    this.ministries.set(id, ministry);
    return ministry;
  }

  async getMinistries(): Promise<Ministry[]> {
    return Array.from(this.ministries.values());
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async createService(insertService: InsertService): Promise<Service> {
    const id = this.serviceCurrentId++;
    const service: Service = { ...insertService, id };
    this.services.set(id, service);
    return service;
  }

  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async getUpcomingServices(limit: number = 5): Promise<Service[]> {
    const now = new Date();
    return Array.from(this.services.values())
      .filter(service => new Date(service.date) >= now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, limit);
  }
  
  async updateService(id: number, updates: Partial<InsertService>): Promise<Service | undefined> {
    const existingService = this.services.get(id);
    if (!existingService) {
      return undefined;
    }
    
    const updatedService: Service = {
      ...existingService,
      ...updates,
      id // Garantir que o ID permaneça o mesmo
    };
    
    this.services.set(id, updatedService);
    return updatedService;
  }

  // Schedule operations
  async getSchedule(id: number): Promise<Schedule | undefined> {
    return this.schedules.get(id);
  }

  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const id = this.scheduleCurrentId++;
    const now = new Date();
    const schedule: Schedule = { 
      ...insertSchedule, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.schedules.set(id, schedule);
    return schedule;
  }

  async updateSchedule(id: number, updates: Partial<InsertSchedule>): Promise<Schedule | undefined> {
    const schedule = this.schedules.get(id);
    if (!schedule) return undefined;

    const updatedSchedule = { 
      ...schedule,
      ...updates,
      updatedAt: new Date()
    };
    this.schedules.set(id, updatedSchedule);
    return updatedSchedule;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    return this.schedules.delete(id);
  }

  async getSchedulesByMinistry(ministryId: number): Promise<Schedule[]> {
    return Array.from(this.schedules.values())
      .filter(schedule => schedule.ministryId === ministryId)
      .sort((a, b) => {
        // Get service dates for sorting
        const serviceA = this.services.get(a.serviceId);
        const serviceB = this.services.get(b.serviceId);
        if (!serviceA || !serviceB) return 0;
        
        return new Date(serviceB.date).getTime() - new Date(serviceA.date).getTime();
      });
  }

  async getSchedulesByService(serviceId: number): Promise<Schedule[]> {
    return Array.from(this.schedules.values())
      .filter(schedule => schedule.serviceId === serviceId);
  }

  // Contestation operations
  async getContestation(id: number): Promise<Contestation | undefined> {
    return this.contestations.get(id);
  }

  async createContestation(insertContestation: InsertContestation): Promise<Contestation> {
    const id = this.contestationCurrentId++;
    const now = new Date();
    const contestation: Contestation = { 
      ...insertContestation, 
      id, 
      createdAt: now 
    };
    this.contestations.set(id, contestation);
    return contestation;
  }

  async updateContestation(id: number, status: string): Promise<Contestation | undefined> {
    const contestation = this.contestations.get(id);
    if (!contestation) return undefined;

    const updatedContestation = { 
      ...contestation,
      status
    };
    this.contestations.set(id, updatedContestation);
    return updatedContestation;
  }

  async getContestationsBySchedule(scheduleId: number): Promise<Contestation[]> {
    return Array.from(this.contestations.values())
      .filter(contestation => contestation.scheduleId === scheduleId);
  }

  async getContestationsByUser(userId: number): Promise<Contestation[]> {
    return Array.from(this.contestations.values())
      .filter(contestation => contestation.userId === userId);
  }

  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskCurrentId++;
    const now = new Date();
    const task: Task = { 
      ...insertTask, 
      id, 
      createdAt: now, 
      updatedAt: now,
      completedAt: null
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask = { 
      ...task,
      ...updates,
      updatedAt: new Date()
    };
    
    // If status is changed to completed, set completedAt date
    if (updates.status === 'completed' && task.status !== 'completed') {
      updatedTask.completedAt = new Date();
    }
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async getTasksByMinistry(ministryId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.ministryId === ministryId);
  }

  async getTasksByStatus(status: TaskStatus): Promise<Task[]> {
    // For overdue status, we need to check due date as well
    if (status === 'overdue') {
      const now = new Date();
      return Array.from(this.tasks.values())
        .filter(task => 
          (task.status === 'pending' && 
           task.dueDate && 
           new Date(task.dueDate) < now)
        );
    }
    
    return Array.from(this.tasks.values())
      .filter(task => task.status === status);
  }

  async getTasksByAssignee(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.assignees.includes(userId));
  }

  // Canteen Menu operations
  async getCanteenMenu(id: number): Promise<CanteenMenu | undefined> {
    return this.canteenMenus.get(id);
  }

  async createCanteenMenu(insertMenu: InsertCanteenMenu): Promise<CanteenMenu> {
    const id = this.canteenMenuCurrentId++;
    const now = new Date();
    const menu: CanteenMenu = { 
      ...insertMenu, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.canteenMenus.set(id, menu);
    return menu;
  }

  async updateCanteenMenu(id: number, updates: Partial<InsertCanteenMenu>): Promise<CanteenMenu | undefined> {
    const menu = this.canteenMenus.get(id);
    if (!menu) return undefined;

    const updatedMenu = { 
      ...menu,
      ...updates,
      updatedAt: new Date()
    };
    this.canteenMenus.set(id, updatedMenu);
    return updatedMenu;
  }

  async deleteCanteenMenu(id: number): Promise<boolean> {
    return this.canteenMenus.delete(id);
  }

  async getCanteenMenusByService(serviceId: number): Promise<CanteenMenu[]> {
    return Array.from(this.canteenMenus.values())
      .filter(menu => menu.serviceId === serviceId);
  }

  // Access Rules operations
  async getAccessRule(id: number): Promise<AccessRule | undefined> {
    return this.accessRules.get(id);
  }

  async createAccessRule(insertRule: InsertAccessRule): Promise<AccessRule> {
    const id = this.accessRuleCurrentId++;
    const rule: AccessRule = { ...insertRule, id };
    this.accessRules.set(id, rule);
    return rule;
  }

  async getAccessRulesByMinistry(ministryId: number): Promise<AccessRule[]> {
    return Array.from(this.accessRules.values())
      .filter(rule => rule.fromMinistryId === ministryId);
  }

  async canAccessMinistry(fromMinistryId: number, toMinistryId: number): Promise<boolean> {
    // Same ministry always has access
    if (fromMinistryId === toMinistryId) return true;
    
    // Check for explicit access rule
    const hasAccessRule = Array.from(this.accessRules.values())
      .some(rule => 
        rule.fromMinistryId === fromMinistryId && 
        rule.toMinistryId === toMinistryId
      );
      
    return hasAccessRule;
  }
}

// Importe a implementação do banco de dados
import { DatabaseStorage } from './database-storage';

// Comentado para referência, agora usando DatabaseStorage
// export const storage = new MemStorage();

// Usando armazenamento de banco de dados PostgreSQL
export const storage = new DatabaseStorage();
