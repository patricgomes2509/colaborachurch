import { pgTable, text, serial, integer, boolean, timestamp, json, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enum values for role type
export type RoleType = "leader" | "volunteer";
export type ServiceStatus = "pending" | "completed" | "cancelled";
export type TaskStatus = "pending" | "overdue" | "completed";
export type Priority = "high" | "medium" | "low";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").unique(),
  phone: text("phone"),
  cpf: text("cpf").unique(),
  birthDate: timestamp("birth_date"),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  role: text("role").$type<RoleType>().notNull().default("volunteer"),
  ministryId: integer("ministry_id").references(() => ministries.id), // Mantido para compatibilidade, será o ministério principal
});

// Tabela para relacionamento muitos-para-muitos entre usuários e ministérios
export const userMinistries = pgTable("user_ministries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  ministryId: integer("ministry_id").notNull().references(() => ministries.id),
}, (table) => {
  return {
    uniqueUserMinistry: uniqueIndex("unique_user_ministry").on(table.userId, table.ministryId),
  };
});

// Ministries table
export const ministries = pgTable("ministries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  colorClass: text("color_class").notNull(),
  slug: text("slug").notNull().unique(),
});

// Services table
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  dayOfWeek: text("day_of_week").notNull(),
  name: text("name").notNull(),
  time: text("time").notNull(),
  status: text("status").$type<ServiceStatus>().notNull().default("pending"),
});

// Schedules table
export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  serviceId: integer("service_id").notNull().references(() => services.id),
  ministryId: integer("ministry_id").notNull().references(() => ministries.id),
  leaderId: integer("leader_id").references(() => users.id),
  members: json("members").$type<{ userId: number, name: string, role: string }[]>().default([]),
  status: text("status").$type<ServiceStatus>().notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Schedule Contestations table
export const contestations = pgTable("contestations", {
  id: serial("id").primaryKey(),
  scheduleId: integer("schedule_id").notNull().references(() => schedules.id),
  userId: integer("user_id").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  ministryId: integer("ministry_id").notNull().references(() => ministries.id),
  createdBy: integer("created_by").notNull().references(() => users.id),
  status: text("status").$type<TaskStatus>().notNull().default("pending"),
  priority: text("priority").$type<Priority>().notNull().default("medium"),
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  assignees: json("assignees").$type<number[]>().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Canteen Menus table
export const canteenMenus = pgTable("canteen_menus", {
  id: serial("id").primaryKey(),
  serviceId: integer("service_id").notNull().references(() => services.id),
  items: json("items").$type<string[]>().notNull(),
  responsibleId: integer("responsible_id").notNull().references(() => users.id),
  status: text("status").$type<ServiceStatus>().notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Access Rules table for cross-ministry visibility
export const accessRules = pgTable("access_rules", {
  id: serial("id").primaryKey(),
  fromMinistryId: integer("from_ministry_id").notNull().references(() => ministries.id),
  toMinistryId: integer("to_ministry_id").notNull().references(() => ministries.id),
  canEdit: boolean("can_edit").notNull().default(false),
}, (table) => {
  return {
    uniqueRule: uniqueIndex("unique_access_rule").on(table.fromMinistryId, table.toMinistryId),
  };
});

// Tabela para notificações de aniversários
export const birthdayNotifications = pgTable("birthday_notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  notifiedDate: timestamp("notified_date").notNull().defaultNow(),
  year: integer("year").notNull(),
  viewed: boolean("viewed").notNull().default(false),
});

// Zod schemas for data insertion
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertUserMinistrySchema = createInsertSchema(userMinistries).omit({ id: true });
export const insertMinistrySchema = createInsertSchema(ministries).omit({ id: true });
export const insertServiceSchema = createInsertSchema(services).omit({ id: true });
export const insertScheduleSchema = createInsertSchema(schedules).omit({ id: true, createdAt: true, updatedAt: true });
export const insertContestationSchema = createInsertSchema(contestations).omit({ id: true, createdAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true, updatedAt: true, completedAt: true });
export const insertCanteenMenuSchema = createInsertSchema(canteenMenus).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAccessRuleSchema = createInsertSchema(accessRules).omit({ id: true });
export const insertBirthdayNotificationSchema = createInsertSchema(birthdayNotifications).omit({ id: true, notifiedDate: true });

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertUserMinistry = z.infer<typeof insertUserMinistrySchema>;
export type UserMinistry = typeof userMinistries.$inferSelect;

export type InsertMinistry = z.infer<typeof insertMinistrySchema>;
export type Ministry = typeof ministries.$inferSelect;

export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;

export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedules.$inferSelect;

export type InsertContestation = z.infer<typeof insertContestationSchema>;
export type Contestation = typeof contestations.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertCanteenMenu = z.infer<typeof insertCanteenMenuSchema>;
export type CanteenMenu = typeof canteenMenus.$inferSelect;

export type InsertAccessRule = z.infer<typeof insertAccessRuleSchema>;
export type AccessRule = typeof accessRules.$inferSelect;

export type InsertBirthdayNotification = z.infer<typeof insertBirthdayNotificationSchema>;
export type BirthdayNotification = typeof birthdayNotifications.$inferSelect;
